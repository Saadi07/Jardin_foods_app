import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  Text,
  FlatList,
  ActivityIndicator,
  View,
  Dimensions,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Card, Button } from "react-native-paper";
import { openDatabase } from "react-native-sqlite-storage";
import { TabView, SceneMap, TabBar } from "react-native-tab-view";
const db = openDatabase({ name: "cartDatabase" });
export default function InvoiceDetails({ route }) {
  const [index, setIndex] = React.useState(0);
  const [warehouse, setWarehouse] = useState("");
  const data = route.params;
  const dataArray = data.data1;
  const salesData = JSON.parse(dataArray.sales);
  const returnData = JSON.parse(dataArray.return);
  const sampleData = JSON.parse(dataArray.sample);
 
  const getWarehouseName = async () => {
    const salesPerson = await AsyncStorage.getItem("salesPerson");
    const salesPersonData = JSON.parse(salesPerson);
    setWarehouse(() => salesPersonData.default_warehouse.name);
    // console.log(warehouse)
  };
 
  useEffect(() => {
    getWarehouseName();
  });
 
  const FirstRoute = () => (
    <FlatList
      data={salesData}
      renderItem={({ item }) => (
        <View>
          <Card style={styles.card}>
            <View>
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "bold",
                  color: "#4d4d4d",
                  color: "#262626",
                }}
              >
                {item.name}
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 2,
                marginTop: 10,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                Quantity: {item.sale_qty}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 0,
                }}
              >
                <Text style={{ color: "#262626" }}>
                  {" "}
                  ${item.actual_price.toFixed(2)}{" "}
                </Text>{" "}
                Promo Price
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 10,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 10,
                }}
              >
                <Text style={{ color: "#262626" }}>
                  {" "}
                  ${(item.actual_price - item.lst_price)}{" "}
                </Text>{" "}
                Discount
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 20,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {" "}
              </Text>
              <Text
                style={{ fontSize: 12, fontWeight: "500", color: "#4d4d4d" }}
              >
                <Text style={{ color: "#262626", marginRight: 40 }}>
                  {" "}
                  ${item.lst_price.toFixed(2)}{" "}
                </Text>{" "}
                Net Price
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 17,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 0,
                }}
              >
                <Text style={{ color: "#262626", marginRight: 20 }}>
                  {" "}
                  ${(item.sale_qty * item.lst_price).toFixed(2)}{" "}
                </Text>{" "}
                Extension
              </Text>
            </View>
          </Card>
          {item.link_items.length != 0 ? (
            <FlatList
              data={item.link_items}
              renderItem={({ item }) => (
                <Card style={styles.cardLink}>
                  <View>
                    <Text
                      style={{
                        fontSize: 14,
                        fontWeight: "bold",
                        color: "#4d4d4d",
                      }}
                    >
                      {item.product.name} (LINK ITEM)
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 2,
                      marginTop: 10,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      Quantity: {item.quantity}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 0,
                      }}
                    >
                      <Text style={{ color: "#262626" }}>
                        {" "}
                        ${item.product.lst_price.toFixed(2)}{" "}
                      </Text>{" "}
                      Promo Price
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 10,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ color: "#262626" }}>
                        {" "}
                        ${(0.0).toFixed(2)}{" "}
                      </Text>{" "}
                      Discount
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 20,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                      }}
                    >
                      <Text style={{ color: "#262626", marginRight: 40 }}>
                        {" "}
                        ${item.product.lst_price.toFixed(2)}{" "}
                      </Text>{" "}
                      Net Price
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 17,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 0,
                      }}
                    >
                      <Text style={{ color: "#262626", marginRight: 20 }}>
                        {" "}
                        ${(item.quantity * item.product.lst_price).toFixed(
                          2
                        )}{" "}
                      </Text>{" "}
                      Extension
                    </Text>
                  </View>
                </Card>
              )}
            />
          ) : (
            <Text> </Text>
          )}
        </View>
      )}
    />
  );

  const SecondRoute = () => (
    <FlatList
      data={returnData}
      renderItem={({ item }) => (
        <View>
          <Card style={styles.card}>
            <View>
              <Text
                style={{ fontSize: 14, color: "#4d4d4d", fontWeight: "bold" }}
              >
                {item.name}
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 2,
                marginTop: 10,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                Quantity: {item.return_qty}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 0,
                }}
              >
                <Text style={{ color: "#262626" }}>
                  {" "}
                  ${item.actual_price}{" "}
                </Text>{" "}
                Promo Price
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 10,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 10,
                }}
              >
                <Text style={{ color: "#262626" }}>
                  {" "}
                  ${(item.actual_price - item.lst_price).toFixed(2)}{" "}
                </Text>{" "}
                Discount
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 20,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{ fontSize: 12, fontWeight: "500", color: "#4d4d4d" }}
              >
                <Text style={{ color: "#262626", marginRight: 40 }}>
                  {" "}
                  ${item.lst_price.toFixed(2)}{" "}
                </Text>{" "}
                Net Price
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 17,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 0,
                }}
              >
                <Text style={{ color: "#262626", marginRight: 20 }}>
                  {" "}
                  ${(item.return_qty * item.lst_price).toFixed(2)}{" "}
                </Text>{" "}
                Extension
              </Text>
            </View>
          </Card>
          {item.link_items.length != 0 ? (
            <FlatList
              data={item.link_items}
              renderItem={({ item }) => (
                <Card style={styles.cardLink}>
                  <View>
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#4d4d4d",
                        fontWeight: "bold",
                      }}
                    >
                      {item.product.name} (LINK ITEM)
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 2,
                      marginTop: 10,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      Quantity: {item.quantity}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 0,
                      }}
                    >
                      <Text style={{ color: "#262626" }}>
                        {" "}
                        ${item.product.lst_price.toFixed(2)}{" "}
                      </Text>{" "}
                      Promo Price
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 10,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ color: "#262626" }}> $0.00 </Text> Discount
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 20,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                      }}
                    >
                      <Text style={{ color: "#262626", marginRight: 40 }}>
                        {" "}
                        ${item.product.lst_price.toFixed(2)}{" "}
                      </Text>{" "}
                      Net Price
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 17,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 0,
                      }}
                    >
                      <Text style={{ color: "#262626", marginRight: 20 }}>
                        {" "}
                        ${(item.quantity * item.product.lst_price).toFixed(
                          2
                        )}{" "}
                      </Text>{" "}
                      Extension
                    </Text>
                  </View>
                </Card>
              )}
            />
          ) : (
            <Text> </Text>
          )}
        </View>
      )}
    />
  );

  const ThirdRoute = () => (
    <FlatList
      data={sampleData}
      renderItem={({ item }) => (
        <View>
          <Card style={styles.card}>
            <View>
              <Text
                style={{ fontSize: 14, color: "#4d4d4d", fontWeight: "bold" }}
              >
                {item.name}
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 2,
                marginTop: 10,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                Quantity: {item.sample_qty}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 0,
                }}
              >
                <Text style={{ color: "#262626" }}>
                  {" "}
                  ${item.actual_price}{" "}
                </Text>{" "}
                Promo Price
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 10,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 10,
                }}
              >
                <Text style={{ color: "#262626" }}>
                  {" "}
                  ${(item.actual_price - item.lst_price).toFixed(2)}{" "}
                </Text>{" "}
                Discount
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 20,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{ fontSize: 12, fontWeight: "500", color: "#4d4d4d" }}
              >
                <Text style={{ color: "#262626", marginRight: 40 }}>
                  {" "}
                  ${item.lst_price.toFixed(2)}{" "}
                </Text>{" "}
                Net Price
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 17,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 0,
                }}
              >
                <Text style={{ color: "#262626", marginRight: 20 }}>
                  {" "}
                  ${(item.sample_qty * item.lst_price).toFixed(2)}{" "}
                </Text>{" "}
                Extension
              </Text>
            </View>
          </Card>
          {item.link_items.length != 0 ? (
            <FlatList
              data={item.link_items}
              renderItem={({ item }) => (
                <Card style={styles.cardLink}>
                  <View>
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#4d4d4d",
                        fontWeight: "bold",
                      }}
                    >
                      {item.product.name} (LINK ITEM)
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 21,
                      marginTop: 10,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#4d4d4d",
                        marginRight: 202,
                      }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ color: "#262626" }}>
                        {" "}
                        ${item.product.lst_price.toFixed(2)}{" "}
                      </Text>{" "}
                      Promo Price:
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 20,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#4d4d4d",
                        marginRight: 220,
                      }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ color: "#262626" }}> $0.00 </Text> Discount
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 20,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#4d4d4d",
                        marginRight: 220,
                      }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ color: "#262626" }}>
                        {" "}
                        ${item.product.lst_price.toFixed(2)}{" "}
                      </Text>{" "}
                      Net Price:
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 17,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#4d4d4d",
                        marginRight: 217,
                      }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ color: "#262626" }}>
                        {" "}
                        ${(item.quantity * item.product.lst_price).toFixed(
                          2
                        )}{" "}
                      </Text>{" "}
                      Extension
                    </Text>
                  </View>
                </Card>
              )}
            />
          ) : (
            <Text> </Text>
          )}
        </View>
      )}
    />
  );
 
  const renderScene = SceneMap({
    first: FirstRoute,
    second: SecondRoute,
    third: ThirdRoute,
  });
  const [routes] = React.useState([
    { key: "first", title: "Sales" },
    { key: "second", title: "Return" },
    { key: "third", title: "Sample" },
  ]);
  const renderTabBar = (props) => (
    <TabBar
      {...props}
      indicatorStyle={{ backgroundColor: "#737373" }}
      style={{ backgroundColor: "white", marginBottom: 8 }}
      renderLabel={({ route }) => (
        <Text style={{ color: "#333333", margin: 8 }}>{route.title}</Text>
      )}
    />
  );
 
  return (
    <View style={styles.container}>
      <View style={styles.screenView}>
        <View style={styles.container2}>
          <View
            style={{
              padding: 10,
              marginTop: 20,
              height: "100%",
              marginBottom: 10,
              borderRadius: 10,
              backgroundColor: "white",
            }}
          >
            <View style={{ marginBottom: 20 }}>
              <View>
                <Text style={{ fontSize: 16, color: "#333333" }}>
                  Customer Invoice:
                </Text>
                <Text style={{ fontSize: 16, color: "#333333", marginTop: 6 }}>
                  {dataArray.invoice_no}
                </Text>
              </View>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "flex-end",
                  marginRight: 80,
                  marginTop: 10,
                }}
              >
                <Text
                  style={{
                    fontSize: 14,
                    color: "#333333",
                    marginRight: 72,
                  }}
                >
                  Warehouse:
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    color: "#333333",
                    flex: 1,
                    flexWrap: "wrap",
                  }}
                >
                  {warehouse}
                </Text>
              </View>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "flex-end",
                  marginRight: 80,
                  marginTop: 10,
                }}
              >
                <Text
                  style={{ fontSize: 14, color: "#333333", marginRight: 80 }}
                >
                  Customer:
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    color: "#333333",
                    flex: 1,
                    flexWrap: "wrap",
                  }}
                >
                  {dataArray.customer_name}
                </Text>
              </View>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "flex-start",
                  marginTop: 10,
                }}
              >
                <Text
                  style={{ fontSize: 14, color: "#333333", marginRight: 35 }}
                >
                  Delivery Address:
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    color: "#333333",
                    flex: 1,
                    flexWrap: "wrap",
                  }}
                >
                  {dataArray.delivery}
                </Text>
              </View>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "flex-start",
                  marginRight: 80,
                  marginTop: 10,
                }}
              >
                <Text
                  style={{ fontSize: 14, color: "#333333", marginRight: 60 }}
                >
                  Invoice Date:
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    color: "#333333",
                    flex: 1,
                    flexWrap: "wrap",
                  }}
                >
                  {dataArray.invoice_date}
                </Text>
              </View>
            </View>
            <TabView
              navigationState={{ index, routes }}
              renderScene={renderScene}
              onIndexChange={setIndex}
              initialLayout={{ width: 60 }}
              renderTabBar={renderTabBar}
            />
          </View>
          <View></View>
        </View>
        <View style={{ backgroundColor: "#3c8", height: 50 }}>
          <Text
            style={{
              color: "white",
              fontWeight: "700",
              fontSize: 24,
              textAlign: "center",
              marginTop: 6,
              marginLeft: 100,
            }}
          >
            Total: ${dataArray.total.toFixed(2)}
          </Text>
        </View>
      </View>
    </View>
  );
}
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ecf0f1",
    padding: 0,
  },
  container2: {
    padding: 15,
    marginBottom: 15,
  },
  screenView: {
    marginBottom: 155,
  },
  card: {
    height: 130,
    borderRadius: 10,
    padding: 8,
    borderWidth: 1,
    borderColor: "#666666",
  },
  cardLink: {
    backgroundColor: "#e6e6e6",
    marginTop: 20,
    height: 130,
    borderRadius: 10,
    padding: 8,
    borderWidth: 1,
    borderColor: "#666666",
  },
  prod: {
    width: 200,
    borderWidth: 2,
  },
  view: {
    flex: 1,
    flexDirection: "row",
  },
  text: {
    marginTop: 3,
    marginBottom: 5,
    color: "#3c8",
    fontSize: 14,
    fontWeight: "600",
  },
  name: {
    fontSize: 14,
    fontWeight: "700",
  },
  no: {
    fontSize: 14,
  },
  vw: {
    flexDirection: "row",
    flex: 1,
    justifyContent: "space-between",
  },
});
