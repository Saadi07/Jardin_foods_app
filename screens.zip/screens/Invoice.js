import React, { useState, useEffect } from "react";
import { StyleSheet, Text, FlatList, View } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Card, Button, ActivityIndicator } from "react-native-paper";
import AwesomeAlert from "react-native-awesome-alerts";
import NetInfo from "@react-native-community/netinfo";
import { openDatabase } from "react-native-sqlite-storage";
import RNHTMLtoPDF from "react-native-html-to-pdf";
import RNPrint from "react-native-print";
import { TabView, SceneMap, TabBar } from "react-native-tab-view";

const db = openDatabase({ name: "cartDatabase" });
const invoiceNumber =
  "INV/" + (Math.floor(Math.random() * 10000) + Math.random() * 3).toFixed(0);

export default function Invoice({ navigation, route }) {
  const [showAlert, setShowAlert] = useState(false);
  const [custName, setCustName] = useState("");
  const [custAddr, setCustAddr] = useState("");
  const [date, setDate] = useState("");
  const [totalSales, setTotalSales] = useState();
  const [totalReturn, setTotalReturn] = useState();
  const [totalInvoice, setTotalInvoice] = useState(0.0);
  const [warehouse, setWarehouse] = useState("");
  const [index, setIndex] = React.useState(0);
  const [isLoading, setLoading] = useState(true);
  const [customerId, setCustomerId] = useState("");
  const [userId, setUserId] = useState("");
  const [warehouseId, setWarehouseId] = useState("");
  const [selectedPrinter, setSelectedPrinter] = useState(null);
  const [sale, setSale] = useState("");
  const [ret, setRet] = useState("");
  const [sample, setSample] = useState("");
  const arrays = route.params;
  const salesData = arrays.salesArray;
  const returnData = arrays.returnArray;
  const sampleData = arrays.sampleArray;
  const [totalSaleTax, setTotalSaleTax] = useState(0);
  const [totalReturnTax, setTotalReturnTax] = useState(0);
  const [totalTax, setTotalTax] = useState(0);
  const [length, setLength] = useState(0);
  const [customerNo, setCustomerNo] = useState("");

  const tableHtml = () => {
    var salesArray = "";
    var returnArray = "";
    var sampleArray = "";
    var len = 0;
    for (var i = 0; i < salesData.length; i++) {
      const ext = (salesData[i].lst_price * salesData[i].sale_qty).toFixed(2);
      salesArray =
        salesArray +
        `<tr class="item">
      <td > <p style="text-align:center">   ${salesData[i].id} </p> </td>
      <td > <p style="text-align:left"> ${salesData[i].name} </p> </td>
      <td > <p style="text-align:center"> ${salesData[i].sale_qty} </p></td>
      <td > <p style="text-align:center">  ${salesData[i].lst_price} </p> </td>
      <td > <p style="text-align:center">  ${ext} </p> </td>
      </tr>`;
      len = len + 1;
      for (var y = 0; y < salesData[i].link_items.length; y++) {
        const ext =
          salesData[i].link_items[y].product.lst_price *
          salesData[i].link_items[y].quantity;
        salesArray =
          salesArray +
          `<tr class="item">
         <td > <p style="text-align:center">   ${salesData[i].link_items[y].product.id} </p> </td>
         <td > <p style="text-align:left"> ${salesData[i].link_items[y].product.name} </p> </td>
         <td > <p style="text-align:center"> ${salesData[i].link_items[y].quantity} </p></td>
         <td > <p style="text-align:center">  ${salesData[i].link_items[y].product.lst_price} </p> </td>
         <td > <p style="text-align:center">  ${ext} </p> </td>
         </tr>`;
        len = len + 1;
      }
    }
    for (var i = 0; i < returnData.length; i++) {
      const ext = (returnData[i].lst_price * returnData[i].return_qty).toFixed(
        2
      );
      if (i == 0) {
        len = len + 1;
        returnArray =
          returnArray +
          `<tr> <td></td><td></td><td style='font-size: 24px;'> Credit </td> </tr>
     <tr class="item">
      <td > <p style="text-align:center">  ${returnData[i].id} </p> </td>
      <td > <p style="text-align:left"> ${returnData[i].name} </p> </td>
      <td > <p style="text-align:center">  -${returnData[i].return_qty} </p></td>
      <td > <p style="text-align:center">  ${returnData[i].lst_price} </p> </td>
      <td > <p style="text-align:center">  -${ext} </p> </td>
      </tr>`;
      } else {
        returnArray =
          returnArray +
          `<tr class="item">
     <td > <p style="text-align:center">   ${returnData[i].id} </p> </td>
     <td > <p style="text-align:left"> ${returnData[i].name} </p> </td>
     <td > <p style="text-align:center"> -${returnData[i].return_qty} </p></td>
     <td > <p style="text-align:center">  ${returnData[i].lst_price} </p> </td>
     <td > <p style="text-align:center">   -${ext} </p> </td>
      </tr>`;
        len = len + 1;
      }
      for (var y = 0; y < returnData[i].link_items.length; y++) {
        const ext = (
          returnData[i].link_items[y].product.lst_price *
          returnData[i].link_items[y].quantity
        ).toFixed(2);
        returnArray =
          returnArray +
          `<tr class="item">
         <td > <p style="text-align:center">   ${returnData[i].link_items[y].product.id} </p> </td>
         <td > <p style="text-align:left"> ${returnData[i].link_items[y].product.name} </p> </td>
         <td > <p style="text-align:center"> -${returnData[i].link_items[y].quantity} </p></td>
         <td > <p style="text-align:center">  ${returnData[i].link_items[y].product.lst_price} </p> </td>
         <td > <p style="text-align:center">  ${ext} </p> </td>
         </tr>`;
        len = len + 1;
      }
    }
    for (var i = 0; i < sampleData.length; i++) {
      const ext = (sampleData[i].lst_price * sampleData[i].sample_qty).toFixed(
        2
      );
      if (i == 0) {
        sampleArray =
          sampleArray +
          `<tr> <td></td><td></td><td style='font-size: 24px;'> Sample </td> </tr>
     <tr class="item">

      <td > <p style="text-align:center">  ${sampleData[i].id} </p> </td>
      <td > <p style="text-align:left"> ${sampleData[i].name} </p> </td>
      <td > <p style="text-align:center">  ${sampleData[i].sample_qty} </p></td>
      <td > <p style="text-align:center">  ${sampleData[i].lst_price} </p> </td>
      <td > <p style="text-align:center">  ${ext} </p> </td>
      </tr>`;
        len = len + 1;
      } else {
        sampleArray =
          sampleArray +
          `<tr class="item">
     <td > <p style="text-align:center">  ${sampleData[i].id} </p> </td>
     <td > <p style="text-align:left"> ${sampleData[i].name} </p> </td>
     <td > <p style="text-align:center">  ${sampleData[i].sample_qty} </p></td>
     <td > <p style="text-align:center">  ${sampleData[i].lst_price} </p> </td>
     <td > <p style="text-align:center">  ${ext} </p> </td>
      </tr>`;
        len = len + 1;
      }
      for (var y = 0; y < sampleData[i].link_items.length; y++) {
        const ext = (
          sampleData[i].link_items[y].product.lst_price *
          sampleData[i].link_items[y].quantity
        ).toFixed(2);
        sampleArray =
          sampleArray +
          `<tr class="item">
         <td > <p style="text-align:center">   ${sampleData[i].link_items[y].product.id} </p> </td>
         <td > <p style="text-align:left"> ${sampleData[i].link_items[y].product.name} </p> </td>
         <td > <p style="text-align:center"> ${sampleData[i].link_items[y].quantity} </p></td>
         <td > <p style="text-align:center">  ${sampleData[i].link_items[y].product.lst_price} </p> </td>
         <td > <p style="text-align:center">  ${ext} </p> </td>
         </tr>`;
        len = len + 1;
      }
    }
    setRet(returnArray);
    setSale(salesArray);
    setSample(sampleArray);
    setLength(len);
    //console.log("len" + length);
  };
  const lengthFunc = () => {
    if (length == 1) {
      return length * 720;
    } else if (length == 2) {
      return length * 390;
    } else if (length == 3) {
      return length * 300;
    } else if (length == 4) {
      return length * 270;
    } else if (length == 5) {
      return length * 200;
    } else if (length == 6) {
      return length * 180;
    } else if (length == 7) {
      return length * 170;
    } else if (length > 7 && length < 11) {
      return length * 120;
    } else if (length >= 11) {
      return length * 100;
    }
  };
  const createPDF = async (choice) => {
    let options = {
      html: `
       <!DOCTYPE html>
<html>
 <head>
     <style>
     .invoice-box {
      max-width: 100%;
      margin: auto;
      padding: 30px;
      font-size: 16px;
      line-height: 24px;
      font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
      color: #555;
  }

         .invoice-box table {
             width: 100%;
             line-height: inherit;
             text-align: left;
             
         }

         .invoice-box table td {
             padding: 5px;
             vertical-align: top;
         }

         .invoice-box table tr td:nth-child(2) {
          text-align: right;
         }

         .invoice-box table tr.top table td {
             padding-bottom: 20px;
         }

         .invoice-box table tr.top table td.title {
             font-size: 45px;
             line-height: 45px;
             color: #333;
         }

         .invoice-box table tr.information table td {
             padding-bottom: 40px;
         }

         .invoice-box table tr.heading td {
             background: #eee;
             border-bottom: 1px solid #ddd;
             font-weight: bold;
         }

         .invoice-box table tr.details td {
             padding-bottom: 20px;
         }

         .invoice-box table tr.item td {
             border-bottom: 1px solid #eee;
         }

         .invoice-box table tr.item.last td {
             border-bottom: none;
         }

         .invoice-box table tr.total td:nth-child(2) {
             border-top: 2px solid #eee;
             font-weight: bold;
         }

         @media only screen and (max-width: 600px) {
             .invoice-box table tr.top table td {
                 width: 100%;
                 display: block;
                 text-align: left;
             }

             .invoice-box table tr.information table td {
                 width: 100%;
                 display: block;
                 text-align: left;
             }
         }

         /** RTL **/
         .invoice-box.rtl {
             direction: rtl;
             font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
         }

         .invoice-box.rtl table {
             text-align: right;
         }

         .invoice-box.rtl table tr td:nth-child(2) {
             text-align: left;
         }
     </style>
 </head>

 <body>
                  
     <div class="invoice-box">
     <div class="col-12">
     <div style="border-bottom: 1px solid black;"/>
     <table>
     <tr>
     <td style="color:#555">
              Invoice No: ${invoiceNumber} <br />
              Date: ${date} 
          </td>
     </tr>
     </table>
 </div>
</div>
         <table cellpadding="0" cellspacing="0">

             <tr class="information">
                 <td colspan="5">
                     <table ">
                         <tr>
                             <td style=" width: 50px; overflow: hidden; ">
                                 Remit To: Jardin Foods Ltd<br />
                                 9615-90th Avenue<br />
                                 PEACE RIVER AB TBS 1GB
                             </td>

                             <td >
                                 Branch/Route Number:390<br />
                                 Tax #:<br />
                                 Payment Term:
                             </td>
                         </tr>
           <tr>
           <td style=" width: 30px; overflow: hidden;margin-right:130px; " >
            Bill To: ${custName} <br />
           Cust #: ${customerNo} <br />
           ${custAddr}
                           </td>

                             <td style=" width: 30px; overflow: hidden;margin-left:200; ">
             Bill To: ${custName}<br />
             Cust #: ${customerNo} <br />
             ${custAddr}
                             </td>
                         </tr>
                     </table>
                 </td>
             </tr>


             <tr class="heading">
                 <td> <p> ITEM NO </p> </td>

                 <td>  <p style="text-align:left">DESCRIPTION </p></td>
                 <td> <p> QTY </p> </td>

                 <td> <p style="text-align:center"> UNIT PRICE </p></td>
                 <td> <p> EXT </p></td>

                 
             </tr>
              ${sample}
               ${ret}
               <tr><td></td><td></td> <td style='font-size: 24px;'> Sales </td> </tr>
               ${sale}
             <tr>
             <td></td>
             <td></td>
             <td></td>
             <td>
             <table cellpadding="0" cellspacing="0" style=" width : 240px; table-layout: fixed;border: 1px solid #eee;margin-top:20px">
             <tr style="">
             <td> Subtotal: </td>
             <td> $${(totalSales - totalReturn).toFixed(2)} </td>
             </tr>
             <tr>
             <td> Tax: </td>
             <td> $${(totalSaleTax - totalReturnTax).toFixed(2)} </td>
             </tr>
             <tr style="background: #eee">
             <td> Total: </td>
             <td> $${totalInvoice.toFixed(2)} </td>
             </tr>

             </Table>
              </td> 
             
             </tr>
         </table>
         
         <table>
         <tr>
         <td>x_________________________ </td>
         </tr>
         <tr>
         <td> Delivered By: Jardin Foods</td>
         </tr>
         <tr>
         <td> (780) 624 8350</td>
         </tr>
         </tr>
         </table>
     </div>
    
 </body>
</html>`,
      fileName: "test",
      directory: "assets",
      height: lengthFunc(),
      width: 600,
    };
    let file = await RNHTMLtoPDF.convert(options);
    if (choice == "print") {
      await RNPrint.print({ filePath: file.filePath });
      navigation.navigate("TabScreen");
    } else {
      navigation.navigate("PdfScreen", { url: file.filePath });
    }
  };

  const printFunc = () => {
    setShowAlert(true);
  };

  const adddata = async () => {
    db.transaction(async (txn) => {
      await txn.executeSql(
        `INSERT INTO Invoice(customer_name,customer_id,user_id,warehouse_id,invoice_no,invoice_date,sales,return,sample,total,delivery,warehouse,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [
          custName,
          customerId,
          userId,
          warehouseId,
          invoiceNumber,
          date,
          JSON.stringify(salesData),
          JSON.stringify(returnData),
          JSON.stringify(sampleData),
          totalInvoice.toFixed(2),
          custAddr,
          warehouse,
          "notposted",
        ],
        (txObj, resultSet) => {
          if (resultSet.rowsAffected >= 1)
            //console.log('added data')
            console.log(resultSet);
          //viewdata();
        },
        (txObj, error) => {
          console.log("Error", error);
        }
      );
    });
  };

  const createTable = async () => {
    db.transaction((tx) => {
      tx.executeSql(
        "CREATE TABLE IF NOT EXISTS Invoice(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT,customer_id INTEGER,user_id INTEGER,warehouse_id INTEGER,invoice_no TEXT,invoice_date TEXT,sales TEXT,return TEXT,sample TEXT,total INTEGER,delivery TEXT,warehouse TEXT,status TEXT)"
      );
    });
  };

  //use this function to generate formated date
  const getFormatedDate = async () => {
    var today = new Date();
    var dd = today.getDate();

    var mm = today.getMonth() + 1;
    var yyyy = today.getFullYear();
    if (dd < 10) {
      dd = "0" + dd;
    }

    if (mm < 10) {
      mm = "0" + mm;
    }
    today = yyyy + "-" + mm + "-" + dd;
    setDate(today);
  };

  const getSalesPerson = async () => {
    const salesPerson = await AsyncStorage.getItem("salesPerson");
    const salesPersonData = JSON.parse(salesPerson);
    setWarehouse(() => salesPersonData.default_warehouse.name);
    setUserId(() => salesPersonData.uid);
    setWarehouseId(() => salesPersonData.default_warehouse.id);
    getFormatedDate();
  };

  const calculateTotal = async () => {
    console.log("Caller");

    const cust = await AsyncStorage.getItem("custDetails");
    const custData = JSON.parse(cust);

    if (custData) {
      setCustName(() => custData.name);
      setCustAddr(() => custData.street);
      setCustomerId(custData.id);
      setCustomerNo(custData.customer_no);

      let salesTotal = calculateSaleTotal(custData);
      let returnTotal = calculateReturnTotal(custData);
      //console.log("Sales: ", salesTotal._3);
      // console.log("Return: ", returnTotal._3);
      console.log("Total Invoice:", salesTotal._3 - returnTotal._3);
      setTotalTax(totalSaleTax - totalReturnTax);
      console.log("total tax", totalTax);
      setTotalInvoice(salesTotal._3 - returnTotal._3 + totalTax);
      setLoading(false);
    }
  };
  //Invoice Scroll view is set screen view style is added tax and total price is numbers now NAN error is resolved
  //Invoice deletion is also resolved
  const computeTax = async (product, customer) => {
    if (customer.tax_exempt == false) {
      if (product.tax.id) {
        let tax =
          (product.tax.percent / 100) * product.lst_price * product.sale_qty;
        return tax;
      }
      return 0;
    }
  };

  const calculateSaleTotal = async (customer) => {
    let totalSales = 0;
    let totalLink = 0;
    let totalTax = 0;
    salesData.filter((product) => {
      product["total_product"] = product.lst_price * product.sale_qty;
      let tax = computeTax(product, customer);
      totalTax = totalTax + tax._3;
      console.log("Sale:", totalTax);
      setTotalSaleTax(totalTax.toFixed(2));
      console.log("sale total", totalSaleTax);
      totalSales = totalSales + product.total_product;
      product.link_items.filter((product) => {
        product["total_link"] = product.product.lst_price * product.quantity;
        totalLink = totalLink + product.total_link;
      });
    });
    setTotalSales(totalSales + totalLink);
    return totalSales + totalLink;
  };

  const calculateReturnTotal = async (customer) => {
    let totalSales = 0;
    let totalLink = 0;
    let totalTax = 0;
    returnData.filter((product) => {
      product["total_product"] = product.lst_price * product.return_qty;
      let tax = computeTax(product, customer);
      totalTax = totalTax + tax._3;
      setTotalReturnTax(totalTax.toFixed(2));
      totalSales = totalSales + product.total_product;
      product.link_items.filter((product) => {
        product["total_link"] = product.product.lst_price * product.quantity;
        totalLink = totalLink + product.total_link;
      });
    });
    setTotalReturn(totalSales + totalLink);
    return totalSales + totalLink;
  };

  useEffect(() => {
    const removeNetInfoSubscription = NetInfo.addEventListener((state) => {
      const offline = !(state.isConnected && state.isInternetReachable);
      const wifi = state.isWifiEnabled;
      if (!offline) {
        getSalesPerson();
        calculateTotal();
        tableHtml();
      } else {
        getSalesPerson();
        calculateTotal();
        tableHtml();
      }
    });

    return () => removeNetInfoSubscription();
  }, []);

  const FirstRoute = () => (
    <FlatList
      data={salesData}
      renderItem={({ item }) => (
        <View>
          <Card style={styles.card}>
            <View>
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "bold",
                  color: "#4d4d4d",
                  color: "#262626",
                }}
              >
                {item.name}
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 2,
                marginTop: 10,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                Quantity: {item.sale_qty}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 0,
                }}
              >
                <Text style={{ color: "#262626" }}>
                  {" "}
                  ${item.actual_price.toFixed(2)}{" "}
                </Text>{" "}
                Promo Price
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 10,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 10,
                }}
              >
                <Text style={{ color: "#262626" }}>
                  {" "}
                  ${(item.actual_price - item.lst_price).toFixed(2)}{" "}
                </Text>{" "}
                Discount
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 20,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {" "}
              </Text>
              <Text
                style={{ fontSize: 12, fontWeight: "500", color: "#4d4d4d" }}
              >
                <Text style={{ color: "#262626", marginRight: 40 }}>
                  {" "}
                  ${item.lst_price.toFixed(2)}{" "}
                </Text>{" "}
                Net Price
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 17,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 0,
                }}
              >
                <Text style={{ color: "#262626", marginRight: 20 }}>
                  {" "}
                  ${(item.sale_qty * item.lst_price).toFixed(2)}{" "}
                </Text>{" "}
                Extension
              </Text>
            </View>
          </Card>
          {item.link_items.length != 0 ? (
            <FlatList
              data={item.link_items}
              renderItem={({ item }) => (
                <Card style={styles.cardLink}>
                  <View>
                    <Text
                      style={{
                        fontSize: 14,
                        fontWeight: "bold",
                        color: "#4d4d4d",
                      }}
                    >
                      {item.product.name} (LINK ITEM)
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 2,
                      marginTop: 10,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      Quantity: {item.quantity}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 0,
                      }}
                    >
                      <Text style={{ color: "#262626" }}>
                        {" "}
                        ${item.product.lst_price.toFixed(2)}{" "}
                      </Text>{" "}
                      Promo Price
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 10,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ color: "#262626" }}>
                        {" "}
                        ${(0.0).toFixed(2)}{" "}
                      </Text>{" "}
                      Discount
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 20,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                      }}
                    >
                      <Text style={{ color: "#262626", marginRight: 40 }}>
                        {" "}
                        ${item.product.lst_price.toFixed(2)}{" "}
                      </Text>{" "}
                      Net Price
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 17,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 0,
                      }}
                    >
                      <Text style={{ color: "#262626", marginRight: 20 }}>
                        {" "}
                        ${(item.quantity * item.product.lst_price).toFixed(
                          2
                        )}{" "}
                      </Text>{" "}
                      Extension
                    </Text>
                  </View>
                </Card>
              )}
            />
          ) : (
            <Text> </Text>
          )}
        </View>
      )}
    />
  );

  const SecondRoute = () => (
    <FlatList
      data={returnData}
      renderItem={({ item }) => (
        <View>
          <Card style={styles.card}>
            <View>
              <Text
                style={{ fontSize: 14, color: "#4d4d4d", fontWeight: "bold" }}
              >
                {item.name}
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 2,
                marginTop: 10,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                Quantity: {item.return_qty}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 0,
                }}
              >
                <Text style={{ color: "#262626" }}>
                  {" "}
                  ${item.actual_price.toFixed(2)}{" "}
                </Text>{" "}
                Promo Price
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 10,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 10,
                }}
              >
                <Text style={{ color: "#262626" }}>
                  {" "}
                  ${(item.actual_price - item.lst_price).toFixed(2)}{" "}
                </Text>{" "}
                Discount
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 20,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{ fontSize: 12, fontWeight: "500", color: "#4d4d4d" }}
              >
                <Text style={{ color: "#262626", marginRight: 40 }}>
                  {" "}
                  ${item.lst_price.toFixed(2)}{" "}
                </Text>{" "}
                Net Price
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 17,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 0,
                }}
              >
                <Text style={{ color: "#262626", marginRight: 20 }}>
                  {" "}
                  ${(item.return_qty * item.lst_price).toFixed(2)}{" "}
                </Text>{" "}
                Extension
              </Text>
            </View>
          </Card>
          {item.link_items.length != 0 ? (
            <FlatList
              data={item.link_items}
              renderItem={({ item }) => (
                <Card style={styles.cardLink}>
                  <View>
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#4d4d4d",
                        fontWeight: "bold",
                      }}
                    >
                      {item.product.name} (LINK ITEM)
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 2,
                      marginTop: 10,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      Quantity: {item.quantity}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 0,
                      }}
                    >
                      <Text style={{ color: "#262626" }}>
                        {" "}
                        ${item.product.lst_price.toFixed(2)}{" "}
                      </Text>{" "}
                      Promo Price
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 10,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ color: "#262626" }}> $0.00 </Text> Discount
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 20,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                      }}
                    >
                      <Text style={{ color: "#262626", marginRight: 40 }}>
                        {" "}
                        ${item.product.lst_price.toFixed(2)}{" "}
                      </Text>{" "}
                      Net Price
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 17,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 0,
                      }}
                    >
                      <Text style={{ color: "#262626", marginRight: 20 }}>
                        {" "}
                        ${(item.quantity * item.product.lst_price).toFixed(
                          2
                        )}{" "}
                      </Text>{" "}
                      Extension
                    </Text>
                  </View>
                </Card>
              )}
            />
          ) : (
            <Text> </Text>
          )}
        </View>
      )}
    />
  );

  const ThirdRoute = () => (
    <FlatList
      data={sampleData}
      renderItem={({ item }) => (
        <View>
          <Card style={styles.card}>
            <View>
              <Text
                style={{ fontSize: 14, color: "#4d4d4d", fontWeight: "bold" }}
              >
                {item.name}
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 2,
                marginTop: 10,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                Quantity: {item.sample_qty}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 0,
                }}
              >
                <Text style={{ color: "#262626" }}>
                  {" "}
                  ${item.actual_price.toFixed(2)}{" "}
                </Text>{" "}
                Promo Price
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 10,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 10,
                }}
              >
                <Text style={{ color: "#262626" }}>
                  {" "}
                  ${(item.actual_price - item.lst_price).toFixed(2)}{" "}
                </Text>{" "}
                Discount
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 20,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{ fontSize: 12, fontWeight: "500", color: "#4d4d4d" }}
              >
                <Text style={{ color: "#262626", marginRight: 40 }}>
                  {" "}
                  ${item.lst_price.toFixed(2)}{" "}
                </Text>{" "}
                Net Price
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginRight: 17,
                marginTop: 2,
              }}
            >
              <Text style={{ fontSize: 14, color: "#4d4d4d", marginRight: 0 }}>
                {""}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#4d4d4d",
                  marginRight: 0,
                }}
              >
                <Text style={{ color: "#262626", marginRight: 20 }}>
                  {" "}
                  ${(item.sample_qty * item.lst_price).toFixed(2)}{" "}
                </Text>{" "}
                Extension
              </Text>
            </View>
          </Card>
          {item.link_items.length != 0 ? (
            <FlatList
              data={item.link_items}
              renderItem={({ item }) => (
                <Card style={styles.cardLink}>
                  <View>
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#4d4d4d",
                        fontWeight: "bold",
                      }}
                    >
                      {item.product.name} (LINK ITEM)
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 21,
                      marginTop: 10,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#4d4d4d",
                        marginRight: 202,
                      }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ color: "#262626" }}>
                        {" "}
                        ${item.product.lst_price.toFixed(2)}{" "}
                      </Text>{" "}
                      Promo Price:
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 20,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#4d4d4d",
                        marginRight: 220,
                      }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ color: "#262626" }}> $0.00 </Text> Discount
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 20,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#4d4d4d",
                        marginRight: 220,
                      }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ color: "#262626" }}>
                        {" "}
                        ${item.product.lst_price.toFixed(2)}{" "}
                      </Text>{" "}
                      Net Price:
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 17,
                      marginTop: 2,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#4d4d4d",
                        marginRight: 217,
                      }}
                    >
                      {""}
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#4d4d4d",
                        marginRight: 10,
                      }}
                    >
                      <Text style={{ color: "#262626" }}>
                        {" "}
                        ${(item.quantity * item.product.lst_price).toFixed(
                          2
                        )}{" "}
                      </Text>{" "}
                      Extension
                    </Text>
                  </View>
                </Card>
              )}
            />
          ) : (
            <Text> </Text>
          )}
        </View>
      )}
    />
  );

  const renderScene = SceneMap({
    first: FirstRoute,
    second: SecondRoute,
    third: ThirdRoute,
  });
  const [routes] = React.useState([
    { key: "first", title: "Sales" },
    { key: "second", title: "Return" },
    { key: "third", title: "Sample" },
  ]);
  const renderTabBar = (props) => (
    <TabBar
      {...props}
      indicatorStyle={{ backgroundColor: "#737373" }}
      style={{ backgroundColor: "white", marginBottom: 8 }}
      renderLabel={({ route }) => (
        <Text style={{ color: "#333333", margin: 8 }}>{route.title}</Text>
      )}
    />
  );

  return (
    <View style={styles.container}>
      <View style={styles.screenView}>
        <View>
          <AwesomeAlert
            show={showAlert}
            showProgress={false}
            message="Do you want to post the invoice?"
            closeOnTouchOutside={true}
            closeOnHardwareBackPress={false}
            showCancelButton={true}
            showConfirmButton={true}
            cancelText="No"
            confirmText="Yes"
            cancelButtonColor="#D0342C"
            confirmButtonColor="#3c8954"
            onCancelPressed={() => {
              setShowAlert(false);
            }}
            onConfirmPressed={() => {
              setShowAlert(false);
              createTable();
              adddata();
              createPDF("print");
            }}
          />
          <View style={styles.container2}>
            {Platform.OS === "android"}
            <View style={{ flexDirection: "row-reverse" }}>
              <Button
                mode="contained"
                color="#3c8"
                icon="printer"
                labelStyle={{ color: "white" }}
                style={{ width: 100, borderRadius: 30 }}
                onPress={printFunc}
              >
                Print
              </Button>
              <Button
                mode="contained"
                color="#3c8"
                icon="eye"
                labelStyle={{ color: "white" }}
                style={{ width: 130, borderRadius: 30, marginRight: 20 }}
                onPress={() => createPDF("preview")}
              >
                Preview
              </Button>
            </View>

            <View
              style={{
                padding: 10,
                marginTop: 20,
                height: "100%",
                marginBottom: 10,
                borderRadius: 10,
                backgroundColor: "white",
              }}
            >
              <View style={{ marginBottom: 20 }}>
                <View>
                  <Text style={{ fontSize: 16, color: "#333333" }}>
                    Customer Invoice:
                  </Text>
                  <Text
                    style={{ fontSize: 16, color: "#333333", marginTop: 6 }}
                  >
                    {invoiceNumber}
                  </Text>
                </View>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "flex-end",
                    marginRight: 80,
                    marginTop: 10,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      color: "#333333",
                      marginRight: 72,
                    }}
                  >
                    Warehouse:
                  </Text>
                  <Text
                    style={{
                      fontSize: 14,
                      color: "#333333",
                      flex: 1,
                      flexWrap: "wrap",
                    }}
                  >
                    {warehouse}
                  </Text>
                </View>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "flex-end",
                    marginRight: 80,
                    marginTop: 10,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      color: "#333333",
                      marginRight: 80,
                    }}
                  >
                    Customer:
                  </Text>
                  <Text
                    style={{
                      fontSize: 14,
                      color: "#333333",
                      flex: 1,
                      flexWrap: "wrap",
                    }}
                  >
                    {custName}
                  </Text>
                </View>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "flex-start",
                    marginTop: 10,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      color: "#333333",
                      marginRight: 35,
                    }}
                  >
                    Delivery Address:
                  </Text>
                  <Text
                    style={{
                      fontSize: 14,
                      color: "#333333",
                      flex: 1,
                      flexWrap: "wrap",
                    }}
                  >
                    {custAddr}
                  </Text>
                </View>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "flex-start",
                    marginRight: 80,
                    marginTop: 10,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      color: "#333333",
                      marginRight: 60,
                    }}
                  >
                    Invoice Date:
                  </Text>
                  <Text
                    style={{
                      fontSize: 14,
                      color: "#333333",
                      flex: 1,
                      flexWrap: "wrap",
                    }}
                  >
                    {date}
                  </Text>
                </View>
              </View>
              <TabView
                navigationState={{ index, routes }}
                renderScene={renderScene}
                onIndexChange={setIndex}
                initialLayout={{ width: 60 }}
                renderTabBar={renderTabBar}
              />
            </View>
          </View>
        </View>
        <View style={{ backgroundColor: "#3c8", height: 50, marginTop: 110 }}>
          <Text
            style={{
              color: "white",
              fontWeight: "700",
              fontSize: 24,
              textAlign: "center",
              marginTop: 6,
              marginLeft: 100,
            }}
          >
            Total: <Text> ${totalInvoice.toFixed(2)} </Text>
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ecf0f1",
    padding: 0,
  },
  container2: {
    padding: 15,
  },
  screenView: {
    marginBottom: 450,
  },
  card: {
    height: 130,
    borderRadius: 10,
    padding: 8,
    borderWidth: 1,
    borderColor: "#666666",
  },
  cardLink: {
    marginTop: 10,
    marginBottom: 10,
    backgroundColor: "#e6e6e6",
    height: 130,
    borderRadius: 10,
    padding: 8,
    borderWidth: 1,
    borderColor: "#666666",
  },
  prod: {
    width: 200,
    borderWidth: 2,
  },
  view: {
    flex: 1,
    flexDirection: "row",
  },
  text: {
    marginTop: 3,
    marginBottom: 5,
    color: "#3c8",
    fontSize: 14,
    fontWeight: "600",
  },
  name: {
    fontSize: 14,
    fontWeight: "700",
  },
  no: {
    fontSize: 14,
  },
  vw: {
    flexDirection: "row",
    flex: 1,
    justifyContent: "space-between",
  },
});
