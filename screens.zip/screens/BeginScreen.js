import React, { useState, useEffect } from "react";
import { StyleSheet, View, Text, Modal, Alert } from "react-native";
import { Button, IconButton, ActivityIndicator } from "react-native-paper";
import AwesomeAlert from "react-native-awesome-alerts";
import ProgressBar from "react-native-animated-progress";
import NetInfo from "@react-native-community/netinfo";
import { openDatabase } from "react-native-sqlite-storage";
import DropDownPicker from "react-native-dropdown-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";
import CookieManager from "@react-native-cookies/cookies";

const db = openDatabase({ name: "cartDatabase" });

export default function Begin({ navigation }) {
  const [showAlert3, setShowAlert3] = useState(false);
  const [showAlert1, setShowAlert1] = useState(false);
  const [loading, setLoading] = useState(false);
  const [percentage, setPercentage] = useState(0.0);
  const [proceed, setProceed] = useState(true);
  const [downloadinText, setDownloadingText] = useState(
    "Downloading the data..."
  );
  const [textAlert, setAlerText] = useState(false);
  const date = new Date().toDateString();
  const [name, setName] = useState("");
  const [loader, setLoader] = useState(false);
  const [open, setOpen] = useState(false);
  const [open1, setOpen1] = useState(false);
  const [internetStatus, setInternetStatus] = useState(true);
  const [value, setValue] = useState("Invoice");
  const [value1, setValue1] = useState("");
  const [userId, setUserId] = useState("");
  const [items, setItems] = useState([
    { label: "Invoicing", value: "Invoice" },
    { label: "Internal Transfer", value: "Internal Transfer" },
  ]);
  const [items1, setItems1] = useState([
    {
      label: "Logout",
      value: "logout",
    },
  ]);

  //console.log(route.name)
  const signOut = async () => {
    try {
      await fetch("https://smtksa.com/web/session/destroy", {
        method: "POST",
        credentials: "same-origin",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          jsonrpc: "2.0",
          params: {},
        }),
      }).then(async (response) => {
        if (response) {
          CookieManager.clearAll().then((success) => {
            console.log("CookieManager.clearAll =>", success);
          });
        }
      });
    } catch (error) {
      console.error(error);
    } finally {
      navigation.navigate("LoginScreen");
    }
  };

  const getdataCust = async () => {
    try {
      await fetch("https://smtksa.com/api/get_customers/", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({}),
      }).then(async (response) => {
        const json = await response.json();
        const result = json.result.result;
        deleteDataCust();
        createTableCust();
        addDataCust(result);
      });
    } catch (error) {
      console.log(error);
    }
  };

  const addDataCust = async (result) => {
    //console.log(result);
    db.transaction(async (txn) => {
      await txn.executeSql(
        `INSERT INTO Customer(data) VALUES (?)`,
        [JSON.stringify(result)],
        (txObj, resultSet) => {
          if (resultSet.rowsAffected >= 1) {
            console.log("Cust added", resultSet);
          }
        },
        (txObj, error) => {
          console.log("Error", error);
        }
      );
    });
  };

  const createTableCust = async () => {
    db.transaction((tx) => {
      tx.executeSql("CREATE TABLE IF NOT EXISTS Customer(data TEXT)");
    });
  };

  const deleteDataCust = async () => {
    db.transaction(async (tx) => {
      await tx.executeSql("DROP TABLE Customer");
    });
  };

  const getdataProd = async () => {
    try {
      // const cookie = await AsyncStorage.getItem('seesion_id');
      await fetch("https://smtksa.com/api/get_products/", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({}),
      }).then(async (response) => {
        const json = await response.json();
        const result = json.result.result;
        deleteDataProd();
        createTableProd();
        adddataProd(result);
      });
    } catch (error) {
      console.log(error);
    }
  };

  const adddataProd = async (result) => {
    db.transaction(async (txn) => {
      await txn.executeSql(
        `INSERT INTO Product(data) VALUES (?)`,
        [JSON.stringify(result)],
        (txObj, resultSet) => {
          if (resultSet.rowsAffected >= 1)
            console.log("Product added", resultSet);
        },
        (txObj, error) => {
          console.log("Error", error);
        }
      );
    });
  };

  const createTableProd = async () => {
    db.transaction((tx) => {
      tx.executeSql("CREATE TABLE IF NOT EXISTS Product(data TEXT)");
    });
  };

  const deleteDataProd = async () => {
    db.transaction(async (tx) => {
      await tx.executeSql("DROP TABLE Product");
    });
  };

  const getdataPricelist = async () => {
    try {
      // const cookie = await AsyncStorage.getItem('seesion_id');
      const res1 = await fetch("https://smtksa.com/api/get_pricelists/", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({}),
      });
      const json = await res1.json();
      const result = json.result.result;
      //console.log(result[3]);
      var length = 0;
      for (let i = 0; i < result.length; i++) {
        length = length + result[i].product_prices.length;
        //console.log(result[i].product_prices.length);
      }
      deleteDataPricelist();
      createTablePricelist();
      adddataPricelist(result, length);
    } catch (error) {
      setShowAlert2(true);
    } finally {
    }
  };

  const adddataPricelist = async (result, length) => {
    try {
      var percent = 0;
      //setProceed(true);
      setDownloadingText("Downloading the Data...");
      //console.log("pricelength:" + length);
      await result.forEach((e) => {
        e.product_prices.forEach((m) => {
          db.transaction(async (txn) => {
            await txn.executeSql(
              `INSERT INTO Pricelist(id,pricelist_id,preschedule,product_id ,product_name,date_start,date_end,compute_price,fixed_price,percent_price) VALUES (?,?,?,?,?,?,?,?,?,?)`,
              [
                m.id,
                m.pricelist_id,
                m.preschedule,
                m.product.id,
                m.product.name,
                m.date_start,
                m.date_end,
                m.compute_price,
                m.fixed_price,
                m.percent_price,
              ],
              (txObj, resultSet) => {
                if (resultSet.rowsAffected >= 1) console.log(resultSet);
                percent = percent + 1;
                //console.log(percent / 73173) * 100;
                setPercentage((percent / length) * 100);
                if (percent == length) {
                  setProceed(false);
                  setDownloadingText("Downloading data completed");
                }
              },
              (txObj, error) => {
                console.log("Errorpricelistadd", error);
              }
            );
          });
        });
      });
    } catch (error) {
    } finally {
    }
  };
  const createTablePricelist = async () => {
    db.transaction((tx) => {
      tx.executeSql(
        "CREATE TABLE IF NOT EXISTS Pricelist(id INTEGER,pricelist_id INTEGER,preschedule TEXT,product_id INTEGER,product_name TEXT,date_start TEXT,date_end TEXT,compute_price TEXT,fixed_price INTEGER,percent_price INTEGER)"
      );
    });
  };

  const deleteDataPricelist = async () => {
    db.transaction(async (tx) => {
      await tx.executeSql("DROP TABLE Pricelist");
    });
  };

  const getUpdates = async () => {
    console.log("herer");
    try {
      // const cookie = await AsyncStorage.getItem('seesion_id');
      const res1 = await fetch(
        "https://smtksa.com/api/get_pricelist_modified",
        {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            jsonrpc: "2.0",
            params: {
              user_id: userId,
            },
          }),
        }
      );
      const json = await res1.json();
      const result = json.result.result;
      const resultLength = result.length;
      // console.log(result);
      if (resultLength != 0 && textAlert == false) {
        setAlerText(true);
        setShowAlert3(true);
        //console.log("pp");
        //setUpdatedRecord(result)
      } else if (resultLength == 0 && textAlert == false) {
        setLoader(false);
        setShowAlert3(true);
        //console.log("uu");
      }

      if (textAlert == true && resultLength != 0) {
        //console.log("here1");
        setShowAlert3(false);
        setUpdatedRecord(result, resultLength);
      }
    } catch (error) {
      setShowAlert3(true);
    } finally {
      setLoader(false);
    }
  };

  const updateRecord = async (item) => {
    return new Promise((resolve, reject) => {
      db.transaction(async (tx) => {
        await tx.executeSql(
          `UPDATE Pricelist set pricelist_id=?, preschedule=?, product_id=?, product_name=? ,compute_price=?, fixed_price=? ,percent_price=?,date_start=? ,date_end=? WHERE id=? `,
          [
            item.pricelist_id,
            item.preschedule,
            item.product.id,
            item.product.name,
            item.compute_price,
            item.fixed_price,
            item.percent_price,
            item.date_start,
            item.date_end,
            item.id,
          ],
          (tx, results) => {
            //updatedRecordIdz.push({ id: item.id });
            if (results.rows.length > 0) {
              percent = percent + 1;
              resolve(true);
              setPercentage((percent / total) * 100);
              if (percent == total) {
                setProceed(false);
                setDownloadingText("Downloading data completed");
              }
            } else {
              resolve(false);
            }
          },
          (txObj, error) => {
            resolve(false);
            percent = percent + 1;
            setPercentage((percent / total) * 100);
            if (percent == total) {
              setProceed(false);
              setDownloadingText("Downloading data completed");
            }
          }
        );
      });
    });
  };

  const deleteRecord = async (item) => {
    return new Promise((resolve, reject) => {
      db.transaction(async (tx) => {
        await tx.executeSql(
          `DELETE FROM Pricelist WHERE id=? `,
          [item.id],
          (tx, results) => {
            //console.log("Im first");
            if (results.rows.length > 0) {
              //updatedRecordIdz.push({ id: item.id });
              resolve(true);
              percent = percent + 1;
              //console.log(percent / total) * 100;
              setPercentage((percent / total) * 100);
              if (percent == total) {
                setProceed(false);
                setDownloadingText("Downloading data completed");
              }
            } else {
              resolve(false);
            }
          },
          (txObj, error) => {
            resolve(false);
            percent = percent + 1;
            //console.log(percent / total) * 100;
            setPercentage((percent / total) * 100);
            if (percent == total) {
              setProceed(false);
              setDownloadingText("Downloading data completed");
            }
          }
        );
      });
    });
  };

  const addRecord = async (item) => {
    return new Promise((resolve, reject) => {
      db.transaction(async (txn) => {
        await txn.executeSql(
          `INSERT INTO Pricelist(id,pricelist_id,preschedule,product_id ,product_name,date_start,date_end,compute_price,fixed_price,percent_price) VALUES (?,?,?,?,?,?,?,?,?,?)`,
          [
            item.id,
            item.pricelist_id,
            item.preschedule,
            item.product.id,
            item.product.name,
            item.date_start,
            item.date_end,
            item.compute_price,
            item.fixed_price,
            item.percent_price,
          ],
          (txObj, resultSet) => {
            if (resultSet.rowsAffected >= 1) {
              resolve(true);
              percent = percent + 1;
              //console.log(percent / total) * 100;
              setPercentage((percent / total) * 100);
              if (percent == total) {
                setProceed(false);
                setDownloadingText("Downloading data completed");
              }
            } else {
              resolve(false);
            }
          },
          (txObj, error) => {
            resolve(false);
            percent = percent + 1;
            //console.log(percent / total) * 100;
            setPercentage((percent / total) * 100);
            if (percent == total) {
              setProceed(false);
              setDownloadingText("Downloading data completed");
            }
          }
        );
      });
    });
  };

  const setUpdatedRecord = async (pricelist, total) => {
    var percent = 0;
    let updatedRecordIdz = [];
    console.log("here2");
    //ERROR CAN OCCUR HEERE!!!!!!!!!!!
    for (const item of pricelist) {
      if (item.mode == "update") {
        let updated = await updateRecord(item);
        if (updated) {
          updatedRecordIdz.push(item.id);
        }
      } else if (item.mode == "delete") {
        let deleted = await deleteRecord(item);
        if (deleted) {
          updatedRecordIdz.push(item.id);
        }
      } else {
        let added = await addRecord(item);
        if (added) {
          updatedRecordIdz.push(item.id);
        }
      }
    }
    //console.log(updatedRecordIdz);
    updateRecordStatusToOdoo(updatedRecordIdz);
  };

  const updateRecordStatusToOdoo = async (updatedRecordIdz) => {
    console.log(updatedRecordIdz);
    try {
      await fetch("https://smtksa.com/api/update_record_status_in_odoo", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          jsonrpc: "2.0",
          params: {
            user_id: userId,
            record_id: updatedRecordIdz,
          },
        }),
      }).then(async (response) => {
        const json = await response.json();
        console.log(json);
      });
      console.log(updatedRecordIdz);
    } catch (error) {
      console.log(error);
    }
  };

  const postdata = async (data) => {
    try {
      await fetch("https://smtksa.com/api/create_invoice", {
        method: "POST",
        credentials: "same-origin",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          jsonrpc: "2.0",
          params: {
            //db: "jardin_foods",
            //login: "admin",
            //password: "admin",
            invoices: data,
          },
        }),
      }).then(async (response) => {
        const json = await response.json();
        // console.log(json);
      });
      //console.log(data + "added");
    } catch (error) {
      console.log(error);
    } finally {
      db.transaction(async (tx) => {
        await tx.executeSql(
          `UPDATE Invoice set status='posted' `,
          [],
          (tx, results) => {},

          (txObj, error) => {
            console.log("Error", error);
          }
        );
      });
    }
  };

  const createInvoices = async () => {
    console.log("kk");
    const invoiceArray = [];
    db.transaction(async (tx) => {
      await tx.executeSql(
        "SELECT * FROM Invoice WHERE status=?",
        ["notposted"],

        (tx, results) => {
          console.log(results);
          if (results.rows.length >= 1) {
            for (var i = 0; i < results.rows.length; i++) {
              //console.log(results.rows.item(i).sales)
              const temp = [];
              JSON.parse(results.rows.item(i).sales).forEach((e) => {
                temp.push({
                  product_id: e.id,
                  quantity: e.sale_qty,
                  actual_price: e.actual_price,
                  price_unit: e.lst_price,
                  transaction_type: e.transaction_type,
                  Sale_type: e.Sale_type,
                  tax: e.tax,
                });
              });
              if (results.rows.item(i).return.length != 0) {
                JSON.parse(results.rows.item(i).return).forEach((e) => {
                  temp.push({
                    product_id: e.id,
                    quantity: e.sale_qty,
                    actual_price: e.actual_price,
                    price_unit: e.lst_price,
                    transaction_type: e.transaction_type,
                    Sale_type: e.Sale_type,
                    tax: e.tax,
                  });
                });
              }
              if (results.rows.item(i).return.length != 0) {
                JSON.parse(results.rows.item(i).sample).forEach((e) => {
                  temp.push({
                    product_id: e.id,
                    quantity: e.sale_qty,
                    actual_price: e.actual_price,
                    price_unit: e.lst_price,
                    transaction_type: e.transaction_type,
                    Sale_type: e.Sale_type,
                    tax: e.tax,
                  });
                });
              }
              var warehouseId = results.rows.item(i).warehouse_id;
              if (results.rows.item(i).warehouse_id == 0) {
                warehouseId = 1;
              }
              const data = {
                partner_id: results.rows.item(i).customer_id,
                invoice_date: results.rows.item(i).invoice_date,
                salesperson_id: results.rows.item(i).user_id,
                warehouse_id: warehouseId,
                invoice_lines: temp,
              };
              invoiceArray.push(data);
            }
            //console.log("kki");
            //setCheck(false)
            postdata(invoiceArray);
          }
        }
      );
    });
  };

  const getName = async () => {
    const salesPerson = await AsyncStorage.getItem("salesPerson");
    const salesPersonData = JSON.parse(salesPerson);
    setName(salesPersonData.username);
    setUserId(() => salesPersonData.uid);
  };

  useEffect(() => {
    const removeNetInfoSubscription = NetInfo.addEventListener((state) => {
      const offline = !(state.isConnected && state.isInternetReachable);
      const wifi = state.isWifiEnabled;
      if (!offline) {
        getName();
        setInternetStatus(true);
        getdataCust();
        getdataProd();
        createInvoices();
      } else {
        getName();
        setInternetStatus(false);
      }
    });

    return () => removeNetInfoSubscription();
  }, []);

  return (
    <View>
      <View>
        <View
          style={{
            backgroundColor: "#3c8",
            height: 58,
            flexDirection: "row",
            justifyContent: "space-between",
          }}
        >
          <Text style={{ padding: 15, fontSize: 20, color: "white" }}>
            {" "}
            Main menu{" "}
          </Text>
          <IconButton
            icon="download"
            mode={"contained"}
            color="white"
            style={{ marginRight: 26 }}
            size={30}
            onPress={() => setShowAlert1(true)}
          >
            {" "}
          </IconButton>
        </View>
        <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
          <View style={{ flexDirection: "row" }}>
            <IconButton
              icon="account-circle"
              mode={"contained"}
              color="grey"
              size={27}
              style={{ marginTop: 15, marginLeft: 20, marginRight: 0 }}
            >
              {" "}
            </IconButton>
            <DropDownPicker
              open={open1}
              placeholder={name}
              value={value1}
              items={items1}
              setOpen={setOpen1}
              setValue={setValue1}
              setItems={setItems1}
              showTickIcon={false}
              textStyle={{ color: "grey" }}
              style={{
                width: 100,
                marginLeft: 0,
                alignSelf: "center",
                backgroundColor: "#f0f3f4",
                borderWidth: 0,
                marginTop: 10,
                height: 55,
              }}
              containerStyle={{ width: 120, marginBottom: 55, padding: 0 }}
              selectedItemContainerStyle={{
                backgroundColor: "#d9d9d9",
              }}
              onChangeValue={(value) => signOut()}
            />
          </View>
          <View style={{ flexDirection: "row", marginRight: 20 }}>
            <IconButton
              icon="calendar"
              mode={"contained"}
              color="grey"
              size={20}
              style={{ height: 50 }}
            >
              {" "}
            </IconButton>
            <Text style={{ marginTop: 20 }}>{date} </Text>
          </View>
        </View>
        <View style={{ justifyContent: "center", alignItems: "center" }}>
          <DropDownPicker
            open={open}
            value={value}
            items={items}
            setOpen={setOpen}
            setValue={setValue}
            setItems={setItems}
            textStyle={{ color: "grey" }}
            style={{
              width: 320,
              alignSelf: "center",
              borderColor: "grey",
              marginTop: 20,
              height: 55,
            }}
            containerStyle={{ width: 320, marginBottom: 55 }}
            selectedItemContainerStyle={{
              backgroundColor: "#d9d9d9",
            }}
            arrowIconStyle={{
              width: 20,
              height: 20,
              color: "grey",
            }}
            tickIconStyle={{
              width: 20,
              height: 20,
              color: "white",
            }}
            onChangeValue={(value) => {
              console.log(value);
            }}
          />

          <Button
            mode="contained"
            color={"#3c8"}
            style={{ width: 240, height: 50, marginTop: 30 }}
            labelStyle={{ fontSize: 20, color: "white" }}
            onPress={() => {
              setLoader(true);
              getUpdates();
            }}
          >
            Begin Day
          </Button>
        </View>
        <AwesomeAlert
          show={showAlert1}
          showProgress={false}
          message={
            internetStatus
              ? "Do you want to download data?"
              : "No Internet Available"
          }
          closeOnTouchOutside={false}
          closeOnHardwareBackPress={false}
          showCancelButton={true}
          showConfirmButton={internetStatus ? true : false}
          cancelText={internetStatus ? "No" : "Okay"}
          confirmText="Yes"
          cancelButtonColor="#D0342C"
          confirmButtonColor="#3c8954"
          onCancelPressed={() => {
            setShowAlert1(false);
          }}
          onConfirmPressed={() => {
            setShowAlert1(false);
            setLoading(true);
            getdataPricelist();
          }}
        />

        {loader ? (
          <Modal visible={loader} transparent={true} animationType={"none"}>
            <View
              style={{
                backgroundColor: "white",
                height: 150,
                marginTop: 300,
                width: 350,
                marginLeft: 20,
              }}
            >
              <ActivityIndicator
                animating={true}
                size={"medium"}
                style={{ marginTop: 40 }}
                color={"#3c8"}
              />
            </View>
          </Modal>
        ) : (
          <AwesomeAlert
            show={showAlert3}
            showProgress={false}
            message={
              textAlert
                ? "New data available for download, Do you want to download?"
                : "No new data available proceed without downloading?"
            }
            closeOnTouchOutside={false}
            closeOnHardwareBackPress={false}
            showCancelButton={true}
            showConfirmButton={true}
            cancelText="No"
            confirmText="Yes"
            cancelButtonColor="#D0342C"
            confirmButtonColor="#3c8954"
            onCancelPressed={() => {
              if (textAlert) {
                setShowAlert3(false);
                setAlerText(false);
                if (value == "Invoice") {
                  navigation.navigate("TabScreen");
                }
              } else {
                setShowAlert3(false);
                if (value == "Invoice") {
                  navigation.navigate("TabScreen");
                }
              }
            }}
            onConfirmPressed={() => {
              setShowAlert3(false);
              if (textAlert) {
                setLoading(true);
                getUpdates();
                setAlerText(false);
              } else {
                if (value == "Invoice") {
                  navigation.navigate("TabScreen");
                }
              }
            }}
          />
        )}

        <Modal visible={loading} transparent={true}>
          <View
            style={{
              backgroundColor: "white",
              height: 150,
              marginTop: 300,
              width: 350,
              marginLeft: 20,
            }}
          >
            <View
              style={{
                flex: 1,
                justifyContent: "center",
                marginRight: 8,
                marginLeft: 8,
              }}
            >
              <Text style={{ marginBottom: 4, marginTop: 22 }}>
                {" "}
                {downloadinText}{" "}
              </Text>
              <ProgressBar
                progress={percentage}
                height={10}
                backgroundColor="#3c8"
              />
              <View
                style={{ flex: 1, flexDirection: "row-reverse", marginTop: 8 }}
              >
                <Button
                  mode="contained"
                  labelStyle={{ color: "white", fontSize: 14 }}
                  style={{ width: 130, marginTop: 6, height: 40 }}
                  onPress={() => {
                    setLoading(false);
                    setPercentage(0.0);
                    navigation.navigate("TabScreen");
                  }}
                  disabled={proceed}
                  color="#3c8"
                  icon="chevron-right"
                  contentStyle={{ flexDirection: "row-reverse" }}
                >
                  Continue
                </Button>
              </View>
            </View>
          </View>
        </Modal>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "flex-start",
    backgroundColor: "#ecf0f1",
    alignItems: "center",
    marginTop: 25,
  },
  viewName: {
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "left",
  },
  text1: {
    textAlign: "right",
  },
  modalBackground: {
    flex: 1,
    alignItems: "center",
    backgroundColor: "#00000040",
  },

  activityIndicatorWrapper: {
    backgroundColor: "#FFFFFF",
    height: 100,
    width: 100,
    borderRadius: 10,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-around",
  },
});
