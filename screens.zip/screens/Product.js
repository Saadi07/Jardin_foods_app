import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  StyleSheet,
  FlatList,
  ActivityIndicator,
} from "react-native";
import SearchBar from "react-native-dynamic-search-bar";
import NumericInput from "react-native-numeric-input";
import { Card, Button, Icon } from "react-native-paper";
import AsyncStorage from "@react-native-async-storage/async-storage";
import ModalDropdown from "react-native-modal-dropdown";

import { openDatabase } from "react-native-sqlite-storage";

const db = openDatabase({ name: "cartDatabase" });

let returnArray = [];
let sampleArray = [];
let salesArray = [];
export default function Product({ navigation, route }) {
  const [isLoading, setLoading] = useState(true);
  const [filteredDataSource, setFilteredDataSource] = useState([]);
  const [masterDataSource, setMasterDataSource] = useState([]);
  const [search, setSearch] = useState("");
  const [menu, setMenu] = useState(0);
  const [returnOption, setReturnOption] = useState(0);
  const [arrayCheck, setArrayCheck] = useState("");
  const date = new Date();

  if (arrayCheck == "yes") {
    salesArray = [];
    returnArray = [];
    sampleArray = [];
  }

  const handleProceed = async () => {
    navigation.navigate("InvoiceScreen", {
      salesArray,
      returnArray,
      sampleArray,
    });
  };

  const viewdata = async () => {
    db.transaction(async (tx) => {
      await tx.executeSql(
        "SELECT * FROM Product",
        [],
        (tx, results) => {
          var temp = [];

          setMasterDataSource(JSON.parse(results.rows.item(0).data));
          setFilteredDataSource(JSON.parse(results.rows.item(0).data));
          setLoading(false);
        },
        (txObj, error) => {
          console.log("Error", error);
        }
      );
    });
  };

  const computeUnitPrices = async (product, productArray, linkCheck) => {
    const cust = await AsyncStorage.getItem("custDetails");
    const customer = JSON.parse(cust);
    const specialProduct = customer.special_products;
    let specialProdCheck = true;
    if (specialProduct.length !== 0) {
      for (const sProduct of specialProduct) {
        if (product.id === sProduct.product.id) {
          //console.log("Special: ", product);
          if (sProduct.type_check == "actual") {
            specialProdCheck = false;
            product["lst_price"] = finalPrice = sProduct.price_unit;
          } else {
            let percentage = sProduct.price_unit;
            specialProdCheck = false;
            let check_price = true;
            let defaultAb = await defaultAbPriclist(product);
            let independent = await independentPriclist(product);
            // console.log("Inde", independent);
            // console.log(defaultAb);
            if (defaultAb) {
              for (i = 0; i < defaultAb.rows.length; i++) {
                let lstProduct = defaultAb.rows.item(i);
                if (
                  (date > lstProduct.date_start &&
                    date < lstProduct.date_end) ||
                  lstProduct.date_start == "0"
                ) {
                  let finalPrice =
                    lstProduct.fixed_price -
                    (lstProduct.fixed_price * percentage) / 100;
                  // console.log("here", finalPrice);
                  product["lst_price"] = finalPrice;
                  if (linkCheck == 0) {
                    productArray.push(product);
                  }
                  check_price = false;
                }
              }
            }
            if (check_price) {
              if (independent) {
                for (let i = 0; i < independent.rows.length; i++) {
                  let lstProduct = independent.rows.item(i);
                  if (
                    (date > lstProduct.date_start &&
                      date < lstProduct.date_end) ||
                    lstProduct.date_start == "0"
                  ) {
                    let finalPrice =
                      lstProduct.fixed_price -
                      (lstProduct.fixed_price * percentage) / 100;
                    //console.log("independent", finalPrice);
                    product["lst_price"] = finalPrice;
                    if (linkCheck == 0) {
                      productArray.push(product);
                    }
                    //console.log(product);
                    check_price = false;
                  }
                }
              }
            }
          }
        }
      }
    }
    let check_price = true;
    if (specialProdCheck) {
      if (customer.pricelist.contract_price && check_price) {
        if (customer.pricelist.contract_pricelist.id) {
          const result = await contractPricelist(customer, product);
          if (result) {
            //console.log("Contract.......");
            for (let i = 0; i < result.rows.length; i++) {
              let lstProduct = result.rows.item(i);
              s;
              if (
                (date > lstProduct.date_start && date < lstProduct.date_end) ||
                lstProduct.date_start == "0"
              ) {
                let finalPrice = lstProduct.fixed_price;
                product["lst_price"] = finalPrice;
                if (linkCheck == 0) {
                  productArray.push(product);
                }
                check_price = false;
              }
            }
          }
        }
      }
      if (customer.pricelist.group_special.id && check_price) {
        const result = await groupSpecialPricelist(customer, product);
        //console.log("Group: ", pricelist);
        if (result) {
          for (let i = 0; i < result.rows.length; i++) {
            let lstProduct = result.rows.item(i);
            if (lstProduct.compute_price == "percent") {
              let percentage = lstProduct.percent_price;
              let check_pricelist = true;
              let defaultAb = await defaultAbPriclist(product);
              let independent = await independentPriclist(product);
              if (defaultAb) {
                for (i = 0; i < defaultAb.rows.length; i++) {
                  let lstProduct = defaultAb.rows.item(i);
                  if (
                    (date > lstProduct.date_start &&
                      date < lstProduct.date_end) ||
                    lstProduct.date_start == "0"
                  ) {
                    let finalPrice =
                      lstProduct.fixed_price -
                      (lstProduct.fixed_price * percentage) / 100;
                    //console.log("here", finalPrice);
                    product["lst_price"] = finalPrice;
                    if (linkCheck == 0) {
                      productArray.push(product);
                    }
                    check_pricelist = false;
                  }
                }
              }
              if (check_pricelist) {
                if (independent) {
                  for (let i = 0; i < independent.rows.length; i++) {
                    let lstProduct = independent.rows.item(i);
                    if (
                      (date > lstProduct.date_start &&
                        date < lstProduct.date_end) ||
                      lstProduct.date_start == "0"
                    ) {
                      let finalPrice =
                        lstProduct.fixed_price -
                        (lstProduct.fixed_price * percentage) / 100;
                      //console.log("independent", finalPrice);
                      product["lst_price"] = finalPrice;
                      if (linkCheck == 0) {
                        productArray.push(product);
                      }
                      check_pricelist = false;
                    }
                  }
                }
              }
            } else {
              if (
                (date > lstProduct.date_start && date < lstProduct.date_end) ||
                lstProduct.date_start == "0"
              ) {
                let finalPrice = lstProduct.fixed_price;
                product["lst_price"] = finalPrice;
                if (linkCheck == 0) {
                  productArray.push(product);
                }
                check_price = false;
              }
            }
          }
        }
      }
      if (customer.pricelist.global_price.id && check_price) {
        const result = await globalPricelist(customer, product);
        if (result) {
          //console.log("Global.......");
          for (let i = 0; i < result.rows.length; i++) {
            let lstProduct = result.rows.item(i);
            if (
              (date > lstProduct.date_start && date < lstProduct.date_end) ||
              lstProduct.date_start == "0"
            ) {
              let finalPrice = lstProduct.fixed_price;
              product["lst_price"] = finalPrice;
              if (linkCheck == 0) {
                productArray.push(product);
              }
              check_price = false;
            }
          }
        }
      }

      if (customer.pricelist.customer_pricing_sch.id && check_price) {
        const result = await SchedulePricelist(customer, product);
        if (result) {
          //console.log("Sch Pricing");
          for (let i = 0; i < result.rows.length; i++) {
            let lstProduct = result.rows.item(i);
            if (
              (date > lstProduct.date_start && date < lstProduct.date_end) ||
              lstProduct.date_start == "0"
            ) {
              let finalPrice = lstProduct.fixed_price;
              product["lst_price"] = finalPrice;
              if (linkCheck == 0) {
                productArray.push(product);
              }
              check_price = false;
            }
          }
        }
      }
      if (customer.pricelist.customer_default.id && check_price) {
        const result = await customerDefaultPricelist(customer, product);
        if (result) {
          for (let i = 0; i < result.rows.length; i++) {
            let lstProduct = result.rows.item(i);
            if (
              (date > lstProduct.date_start && date < lstProduct.date_end) ||
              lstProduct.date_start == "0"
            ) {
              let finalPrice = lstProduct.fixed_price;
              product["lst_price"] = finalPrice;
              if (linkCheck == 0) {
                productArray.push(product);
              }
              check_price = false;
            }
          }
        }
      }
      if (check_price) {
        if (linkCheck == 0) {
          productArray.push(product);
        }
      }
    }
  };
  const computeActualPrices = async (product) => {
    const cust = await AsyncStorage.getItem("custDetails");
    const customer = JSON.parse(cust);
    let checkPrice = true;
    if (customer.pricelist.customer_pricing_sch.id && checkPrice) {
      const result = await SchedulePricelist(customer, product);
      if (result) {
        for (let i = 0; i < result.rows.length; i++) {
          let lstProduct = result.rows.item(i);
          if (
            (date > Date.parse(lstProduct.date_start) &&
              date < Date(lstProduct.date_end)) ||
            lstProduct.date_start == "0"
          ) {
            let finalPrice = lstProduct.fixed_price;
            product["actual_price"] = finalPrice;
            checkPrice = false;
          }
        }
      }
    }
    if (customer.pricelist.customer_default.id && checkPrice) {
      const result = await customerDefaultPricelist(customer, product);
      if (result) {
        for (let i = 0; i < result.rows.length; i++) {
          let lstProduct = result.rows.item(i);
          if (
            (date > Date.parse(lstProduct.date_start) &&
              date < Date.parse(lstProduct.date_end)) ||
            lstProduct.date_start == "0"
          ) {
            let finalPrice = lstProduct.fixed_price;
            product["actual_price"] = finalPrice;
            checkPrice = false;
          }
        }
      }
    }
  };

  const defaultAbPriclist = async (product) => {
    return new Promise((resolve, reject) => {
      db.transaction(async (tx) => {
        tx.executeSql(
          "SELECT * FROM Pricelist WHERE preschedule=2 AND product_id=?",
          [product.id],
          async (tx, results) => {
            if (results.rows.length > 0) {
              resolve(results);
            } else {
              resolve(false);
            }
          }
        );
      });
    });
  };

  const independentPriclist = async (product) => {
    return new Promise((resolve, reject) => {
      db.transaction(async (tx) => {
        tx.executeSql(
          "SELECT * FROM Pricelist WHERE preschedule=904 AND product_id=?",
          [product.id],
          async (tx, results) => {
            if (results.rows.length > 0) {
              resolve(results);
            } else {
              resolve(false);
            }
          }
        );
      });
    });
  };

  const contractPricelist = async (customer, product) => {
    return new Promise((resolve, reject) => {
      db.transaction(async (tx) => {
        tx.executeSql(
          "SELECT * FROM Pricelist WHERE pricelist_id= ? AND product_id=?",
          [customer.pricelist.contract_pricelist.id, product.id],
          async (tx, results) => {
            if (results.rows.length > 0) {
              resolve(results);
            } else {
              resolve(false);
            }
          }
        );
      });
    });
  };

  const SchedulePricelist = async (customer, product) => {
    return new Promise((resolve, reject) => {
      db.transaction(async (tx) => {
        tx.executeSql(
          "SELECT * FROM Pricelist WHERE pricelist_id= ? AND product_id=? ",
          [customer.pricelist.customer_pricing_sch.id, product.id],
          async (tx, results) => {
            if (results.rows.length > 0) {
              resolve(results);
            } else {
              resolve(false);
            }
          }
        );
      });
    });
  };

  const groupSpecialPricelist = async (customer, product) => {
    return new Promise((resolve, reject) => {
      db.transaction(async (tx) => {
        tx.executeSql(
          "SELECT * FROM Pricelist WHERE pricelist_id= ? AND product_id=? ",
          [customer.pricelist.group_special.id, product.id],
          async (tx, results) => {
            if (results.rows.length > 0) {
              resolve(results);
            } else {
              resolve(false);
            }
          }
        );
      });
    });
  };

  const globalPricelist = async (customer, product) => {
    return new Promise((resolve, reject) => {
      db.transaction(async (tx) => {
        tx.executeSql(
          "SELECT * FROM Pricelist WHERE pricelist_id= ? AND product_id=? ",
          [customer.pricelist.global_price.id, product.id],
          async (tx, results) => {
            if (results.rows.length > 0) {
              resolve(results);
            } else {
              resolve(false);
            }
          }
        );
      });
    });
  };

  const customerDefaultPricelist = async (customer, product) => {
    return new Promise((resolve, reject) => {
      db.transaction(async (tx) => {
        tx.executeSql(
          "SELECT * FROM Pricelist WHERE pricelist_id= ? AND product_id=? ",
          [customer.pricelist.customer_default.id, product.id],
          async (tx, results) => {
            if (results.rows.length > 0) {
              resolve(results);
            } else {
              resolve(false);
            }
          }
        );
      });
    });
  };

  async function handleQuantity(qty, prod) {
    if (menu == 0) {
      if (!qty == 0) {
        let product = salesArray.find((product) => product.id === prod.id);
        if (product) {
          prod["sale_qty"] = qty;
          product["sale_qty"] = prod.sale_qty;
        } else {
          prod["actual_price"] = 0;
          prod["sale_type"] = "sales";
          prod["transaction_type"] = "S";
          prod["sale_qty"] = qty;
          computeUnitPrices(prod, salesArray, 0);
          computeActualPrices(prod);
          if (prod.link_items) {
            for (const linkProduct of prod.link_items) {
              linkProduct.product["lst_price"] = 0;
              computeUnitPrices(linkProduct.product, 1);
            }
          }
          console.log("I m here");
          console.log("REM: ", salesArray);
        }
      } else {
        prod["sale_qty"] = 0;
        let remainingArr = salesArray.filter(
          (product) => product.id != prod.id
        );
        salesArray = remainingArr;
        //
      }
    } else if (menu == 1) {
      if (!qty == 0) {
        let product = returnArray.find((product) => product.id === prod.id);
        if (product) {
          product["return_qty"] = qty;
        } else {
          prod["actual_price"] = 0;
          prod["sale_type"] = returnOption;
          prod["transaction_type"] = "C";
          prod["return_qty"] = qty;
          computeUnitPrices(prod, returnArray, 0);
          computeActualPrices(prod);
          if (prod.link_items) {
            for (const linkProduct of prod.link_items) {
              linkProduct.product["lst_price"] = 0;
              computeUnitPrices(linkProduct.product, 1);
            }
          }
          console.log("Return ", returnArray);
        }
      } else {
        let product = returnArray.find((product) => product.id === prod.id);
        product["return_qty"] = 0;
        let remainingArr = returnArray.filter(
          (product) => product.id != prod.id
        );
        returnArray = remainingArr;
      }
    } else {
      if (!qty == 0) {
        let product = sampleArray.find((product) => product.id === prod.id);
        if (product) {
          product["qty"] = qty;
        } else {
          prod["actual_price"] = 0;
          prod["sale_type"] = "sample";
          prod["transaction_type"] = "F";
          prod["sample_qty"] = qty;
          computeUnitPrices(prod, sampleArray, 0);
          computeActualPrices(prod);
          if (prod.link_items) {
            for (const linkProduct of prod.link_items) {
              linkProduct.product["lst_price"] = 0;
              computeUnitPrices(linkProduct.product, 1);
            }
          }
        }
      } else {
        let product = sampleArray.find((product) => product.id === prod.id);
        product["sample_qty"] = 0;
        let remainingArr = sampleArray.filter(
          (product) => product.id != prod.id
        );
        sampleArray = remainingArr;
      }
    }
  }

  const searchFilterFunction = (text) => {
    setArrayCheck("no");
    if (text) {
      const newData = masterDataSource.filter(function (item) {
        const name = item.name ? item.name.toUpperCase() : "".toUpperCase();
        const itemNo = item.item_no
          ? item.item_no.toUpperCase()
          : "".toUpperCase();
        const barcode = item.barcodes;
        if (barcode) {
          let barcodeStr = barcode.join("");
          const textData = text.toUpperCase();
          return (
            name.indexOf(textData) > -1 ||
            itemNo.indexOf(textData) > -1 ||
            barcodeStr.indexOf(textData) > -1
          );
        }
        const textData = text.toUpperCase();
        return name.indexOf(textData) > -1 || itemNo.indexOf(textData) > -1;
      });
      setFilteredDataSource(newData);
      setSearch(text);
    } else {
      setFilteredDataSource(masterDataSource);
      setSearch(text);
    }
  };

  const onClearfunc = () => {
    setFilteredDataSource(masterDataSource);
  };

  useEffect(() => {
    const data1 = route.params;
    setArrayCheck(data1.data);
    viewdata();
  }, []);

  return (
    <View style={styles.container}>
      {isLoading ? (
        <ActivityIndicator />
      ) : (
        <View style={styles.paragraph}>
          <View style={styles.searchview}>
            <SearchBar
              placeholder="Search here"
              onChangeText={(text) => searchFilterFunction(text)}
              value={search}
              onClearPress={onClearfunc}
            />
          </View>
          <View style={{ height: 40 }}>
            <View
              style={{ marginLeft: 30, marginTop: 4, flexDirection: "row" }}
            >
              <ModalDropdown
                options={["Sales", "Return", "Sample"]}
                textStyle={{
                  fontSize: 20,
                  color: "#4d4d4d",
                  textDecorationLine: "underline",
                }}
                defaultValue="Sales"
                dropdownStyle={{
                  width: 200,
                  height: 250,
                }}
                dropdownTextStyle={{ fontSize: 20 }}
                onSelect={(e) => {
                  setMenu(e);
                  setArrayCheck("no");
                }}
                dropdownTextHighlightStyle={{
                  backgroundColor: "#3c8",
                  color: "white",
                }}
                showSearch={true}
              />
              {menu == 1 ? (
                <View>
                  <ModalDropdown
                    options={[
                      "Return to Inventory",
                      "Promotional Product",
                      "Damaged",
                      "Stale",
                      "Price Adjustment",
                    ]}
                    style={{ marginLeft: 80 }}
                    textStyle={{
                      fontSize: 20,
                      color: "#4d4d4d",
                      textDecorationLine: "underline",
                    }}
                    defaultValue="Return to Inventory"
                    dropdownStyle={{
                      width: 200,
                      height: 300,
                    }}
                    onSelect={(e) => {
                      setReturnOption(e);
                      //if (e == 0) {
                      //   setReturnOption("Return to Inventory");
                      // } else if (e == 1) {
                      //  setReturnOption("Promotional Product");
                      // } else if (e == 2) {
                      //  setReturnOption("Damaged");
                      //} else if (e == 3) {
                      // setReturnOption("Stale");
                      // } else {
                      //  setReturnOption("Price Adjustment");
                      // }
                    }}
                    dropdownTextStyle={{ fontSize: 20 }}
                    dropdownTextHighlightStyle={{
                      backgroundColor: "#3c8",
                      color: "white",
                    }}
                    showSearch={true}
                  />
                </View>
              ) : (
                <Text> '' </Text>
              )}
            </View>
          </View>
          <View style={styles.prodview}>
            <FlatList
              data={filteredDataSource}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <Card style={styles.card}>
                  <View style={styles.vw}>
                    <Text style={styles.name}> {item.name} </Text>
                    <Text style={styles.no}> {item.item_no} </Text>
                    <Text style={styles.text}> {item.id} </Text>
                    {menu == 0 ? (
                      <NumericInput
                        minValue={0}
                        initValue={item.sale_qty}
                        onLimitReached={() => {
                          item["sale_qty"] = 0;
                          let remainingArr = salesArray.filter(
                            (product) => product.id != item.id
                          );
                          salesArray = remainingArr;
                          console.log("REM: ", remainingArr);

                          console.log("Product Array: ", salesArray);
                        }}
                        value={0}
                        //svalue={item.sale_qty}
                        valueType="integer"
                        iconStyle={{ color: "white" }}
                        borderColor="white"
                        containerStyle={{
                          backgroundColor: "white",
                          marginTop: 8,
                        }}
                        rightButtonBackgroundColor="#3c8"
                        leftButtonBackgroundColor="#3c8"
                        totalWidth={140}
                        totalHeight={35}
                        onChange={(e) => {
                          //console.log('l')
                          handleQuantity(e, item);
                        }}
                      />
                    ) : menu == 1 ? (
                      <View>
                        <NumericInput
                          minValue={0}
                          value={0}
                          initValue={item.return_qty}
                          onLimitReached={() => {
                            item["return_qty"] = 0;
                            let remainingArr = returnArray.filter(
                              (product) => product.id != item.id
                            );
                            returnArray = remainingArr;
                            console.log("REM: ", remainingArr);

                            console.log("return Array: ", returnArray);
                          }}
                          iconStyle={{ color: "white" }}
                          borderColor="white"
                          containerStyle={{
                            backgroundColor: "white",
                            marginTop: 8,
                          }}
                          rightButtonBackgroundColor="#3c8"
                          leftButtonBackgroundColor="#3c8"
                          totalWidth={140}
                          totalHeight={35}
                          onChange={(e) => handleQuantity(e, item)}
                        />
                      </View>
                    ) : (
                      <View></View>
                    )}
                    {menu == 2 ? (
                      <View>
                        <NumericInput
                          minValue={0}
                          value={0}
                          initValue={item.sample_qty}
                          onLimitReached={() => {
                            item["sample_qty"] = 0;
                            let remainingArr = returnArray.filter(
                              (product) => product.id != item.id
                            );
                            sampleArray = remainingArr;
                            console.log("REM: ", remainingArr);

                            console.log("sample Array: ", sampleArray);
                          }}
                          iconStyle={{ color: "white" }}
                          borderColor="white"
                          containerStyle={{
                            backgroundColor: "white",
                            marginTop: 8,
                          }}
                          rightButtonBackgroundColor="#3c8"
                          leftButtonBackgroundColor="#3c8"
                          totalWidth={140}
                          totalHeight={35}
                          onChange={(e) => handleQuantity(e, item)}
                        />
                      </View>
                    ) : (
                      <View></View>
                    )}
                  </View>
                </Card>
              )}
            />
          </View>
          <View style={{ marginRight: 15, marginLeft: 15 }}>
            <Button
              mode="contained"
              labelStyle={{ color: "white", fontSize: 16 }}
              onPress={() => handleProceed()}
              color="#3c8"
              icon="chevron-right"
              contentStyle={{ flexDirection: "row-reverse" }}
            >
              Proceed
            </Button>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ecf0f1",
    padding: 0,
  },
  searchview: {
    height: 60,
    marginBottom: 10,
    justifyContent: "flex-end",
  },
  prodview: {
    marginTop: 8,
    marginRight: 15,
    marginLeft: 15,
  },
  paragraph: {
    marginBottom: 310,
  },
  card: {
    marginBottom: 10,
    height: 130,
    borderRadius: 10,
  },
  text: {
    marginTop: 3,
    marginBottom: 5,
    color: "#3c8",
    fontSize: 14,
    fontWeight: "600",
  },
  name: {
    fontSize: 14,
    fontWeight: "700",
  },
  no: {
    fontSize: 14,
  },
  vw: {
    marginLeft: 4,
  },
});
