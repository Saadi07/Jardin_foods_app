import React from "react";

import { createNativeStackNavigator } from "@react-navigation/native-stack";

import Login from "./Login.js";
import TabScreen from "./TabScreen";
import Product from "./Product";
import Customer from "./Customer";
import Invoice from "./Invoice";
import Begin from "./BeginScreen";
import InvoiceDetails from "./InvoiceDetails";

const Stack = createNativeStackNavigator();

const RootStackScreen = ({ navigation }) => (
  <Stack.Navigator initialRouteName="LoginScreen">
    <Stack.Screen
      name="LoginScreen"
      options={{ headerShown: false }}
      component={Login}
    />
    <Stack.Screen
      name="BeginScreen"
      options={{
        headerStyle: { backgroundColor: "#3c8", height: 70 },
        headerBackVisible: false,
        title: "Main Menu",
        headerTitleStyle: {
          color: "white",
        },
        headerShown: false,
      }}
      component={Begin}
    />
    <Stack.Screen
      name="MainScreen"
      options={{
        headerStyle: { backgroundColor: "#3c8", height: 70 },
        headerBackVisible: true,
        title: "Invoice",
        headerTitleStyle: {
          color: "white",
        },
        headerShown: true,
      }}
      component={TabScreen}
    />
    <Stack.Screen
      name="CustomerScreen"
      options={{
        headerStyle: { backgroundColor: "#3c8", height: 70 },
        title: "Customers",
        headerTitleStyle: {
          color: "white",
        },
      }}
      component={Customer}
    />
    <Stack.Screen
      name="ProductScreen"
      options={{
        headerStyle: { backgroundColor: "#3c8", height: 70 },
        title: "Products",
        headerTitleStyle: {
          color: "white",
        },
      }}
      component={Product}
    />
    <Stack.Screen
      name="InvoiceScreen"
      options={{
        headerStyle: { backgroundColor: "#3c8", height: 70 },
        title: "Create Invoice",
        headerTitleStyle: {
          color: "white",
        },
      }}
      component={Invoice}
    />
    <Stack.Screen
      name="InvoiceDetailScreen"
      options={{
        headerStyle: { backgroundColor: "#3c8", height: 70 },
        title: "Invoice Details",
        headerTitleStyle: {
          color: "white",
        },
      }}
      component={InvoiceDetails}
    />
  </Stack.Navigator>
);

export default RootStackScreen;
