import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Text,
  View,
  Image,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";
import SearchBar from "react-native-dynamic-search-bar";
import AsyncStorage from "@react-native-async-storage/async-storage";
//import { openDatabase } from "react-native-sqlite-storage";
import NetInfo from "@react-native-community/netinfo";

import { openDatabase } from "react-native-sqlite-storage";
const db = openDatabase({ name: "cartDatabase" });

const Home = ({ navigation }) => {
  const [isLoading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filteredDataSource, setFilteredDataSource] = useState([]);
  const [masterDataSource, setMasterDataSource] = useState([]);
  const [isOffline, setOfflineStatus] = useState(false);

  const postdata = async (data) => {
    try {
      const res1 = await fetch("https://smtksa.com/api/create_invoice", {
        method: "POST",
        credentials: "same-origin",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          jsonrpc: "2.0",
          params: {
            // db: "jardin_foods",
            // login: "admin",
            // password: "admin",
            invoices: data,
          },
        }),
      }).then(async (response) => {
        const data = await response.json();
        console.log("response:", data);
        console.log(data + "added");
      });
    } catch (error) {
      console.log(error);
    } finally {
      db.transaction(async (tx) => {
        await tx.executeSql(
          `UPDATE Invoice set status='posted' `,
          [],
          (tx, results) => {},

          (txObj, error) => {
            console.log("Error", error);
          }
        );
      });
    }
  };

  const createInvoices = async () => {
    console.log("kk");
    const invoiceArray = [];
    db.transaction(async (tx) => {
      await tx.executeSql(
        "SELECT * FROM Invoice WHERE status=?",
        ["notposted"],

        (tx, results) => {
          console.log("create Invoice", results);
          if (results.rows.length >= 1) {
            for (var i = 0; i < results.rows.length; i++) {
              //console.log(results.rows.item(i).sales)
              const temp = [];
              JSON.parse(results.rows.item(i).sales).forEach((e) => {
                //console.log("sale type", e.sale_type);
                temp.push({
                  product_id: e.id,
                  quantity: e.sale_qty,
                  actual_price: e.actual_price,
                  price_unit: e.lst_price,
                  transaction_type: e.transaction_type,
                  sale_type: "sales",
                  //taxes: e.tax,
                });
                console.log("Sale object", temp);
              });
              //console.log("here1");
              if (results.rows.item(i).return.length != 0) {
                JSON.parse(results.rows.item(i).return).forEach((e) => {
                  //console.log("Return", e.sale_type);
                  temp.push({
                    product_id: e.id,
                    quantity: e.return_qty,
                    actual_price: e.actual_price,
                    price_unit: e.lst_price,
                    transaction_type: e.transaction_type,
                    sale_type: e.sale_type,
                    //taxes: e.tax,
                  });
                  console.log("Return object", temp);
                });
              }
              if (results.rows.item(i).sample.length != 0) {
                JSON.parse(results.rows.item(i).sample).forEach((e) => {
                  console.log("Sample type", e.sale_type);
                  temp.push({
                    product_id: e.id,
                    quantity: e.sample_qty,
                    actual_price: e.actual_price,
                    price_unit: e.lst_price,
                    transaction_type: e.transaction_type,
                    sale_type: "sample",
                    //taxes: e.tax,
                  });
                  console.log("sample object", temp);
                });
              }
              var warehouseId = results.rows.item(i).warehouse_id;
              if (results.rows.item(i).warehouse_id == 0) {
                warehouseId = 1;
              }
              //console.log("User:", results.rows.item(i).user_id)
              const data = {
                partner_id: results.rows.item(i).customer_id,
                name: results.rows.item(i).invoice_no,
                invoice_date: results.rows.item(i).invoice_date,
                salesperson_id: results.rows.item(i).user_id,
                warehouse_id: warehouseId,
                invoice_lines: temp,
              };
              invoiceArray.push(data);
            }
            console.log("kki");
            //setCheck(false)
            postdata(invoiceArray);
          }
        }
      );
    });
  };

  const viewdata = async () => {
    db.transaction(async (tx) => {
      await tx.executeSql(
        "SELECT * FROM Customer",
        [],
        (tx, results) => {
          var temp = [];
          //console.log(results.rows.item(0));
          setMasterDataSource(JSON.parse(results.rows.item(0).data));
          setFilteredDataSource(JSON.parse(results.rows.item(0).data));
          setLoading(false);
        },
        (txObj, error) => {
          console.log("Error", error);
        }
      );
    });
  };

  useEffect(() => {
    const removeNetInfoSubscription = NetInfo.addEventListener((state) => {
      const offline = !(state.isConnected && state.isInternetReachable);
      const wifi = state.isWifiEnabled;
      if (!offline) {
        createInvoices();
      }
      viewdata();
    });

    return () => removeNetInfoSubscription();
  }, []);

  const searchFilterFunction = (text) => {
    // Check if searched text is not blank
    if (text) {
      const newData = filteredDataSource.filter(function (item) {
        const name = item.name ? item.name.toUpperCase() : "".toUpperCase();
        const customerNo = item.customer_no
          ? item.customer_no.toUpperCase()
          : "".toUpperCase();
        const textData = text.toUpperCase();
        return name.indexOf(textData) > -1 || customerNo.indexOf(textData) > -1;
      });
      setFilteredDataSource(newData);
      setSearch(text);
    } else {
      setFilteredDataSource(masterDataSource);
      setSearch(text);
    }
  };
  const onClearfunc = () => {
    setFilteredDataSource(masterDataSource);
  };

  //Storing Customer data in async storage
  const storeCustomerData = async (cust) => {
    try {
      //console.log("Hello", cust);
      const jsonValue = JSON.stringify(cust);
      await AsyncStorage.setItem("custDetails", jsonValue);
      const getit = await AsyncStorage.getItem("custDetails");
      //console.log(cust.name);
      // Remember to remove customer from async storage after invoice creation
      navigation.navigate("ProductScreen", { data: "yes" });
    } catch (e) {
      // saving error

      console.log("Error", e);
    }
  };
  return (
    <View style={styles.container}>
      {isLoading ? (
        <ActivityIndicator />
      ) : (
        <View>
          <View style={styles.searchview}>
            <SearchBar
              placeholder="Search here"
              onChangeText={(text) => searchFilterFunction(text)}
              value={search}
              onClearPress={onClearfunc}
            />
          </View>
          <View style={styles.cusview}>
            <FlatList
              data={filteredDataSource}
              keyExtractor={({ id }, index) => id}
              renderItem={({ item }) => (
                <>
                  <TouchableOpacity
                    //onPress={() => actionOnRow(item)}
                    onPress={() => storeCustomerData(item)}
                  >
                    <View
                      style={{
                        flexDirection: "row",
                        padding: 10,
                        marginBottom: 10,
                        borderRadius: 10,
                        backgroundColor: "white",
                      }}
                    >
                      <Image
                        source={require("../assets/customer2.png")}
                        style={{
                          width: 60,
                          height: 60,
                          borderRadius: 60,
                          marginRight: 20 / 2,
                        }}
                      />
                      <View>
                        <View>
                          <Text style={{ fontSize: 14, fontWeight: "700" }}>
                            {item.name}
                          </Text>
                        </View>
                        <View>
                          <Text style={{ fontSize: 16, opacity: 0.7 }}>
                            {item.parent_id}
                          </Text>
                        </View>
                        <View>
                          <Text
                            style={{
                              fontSize: 14,
                              opacity: 0.8,
                              color: "#3c8",
                            }}
                          >
                            {item.street}
                          </Text>
                        </View>
                      </View>
                    </View>
                  </TouchableOpacity>
                </>
              )}
            />
          </View>
        </View>
      )}
    </View>
  );
};

export default Home;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ecf0f1",
    padding: 0,
  },
  searchview: {
    height: 60,
    marginBottom: 10,
    justifyContent: "flex-end",
  },
  cusview: {
    marginTop: 8,
    marginRight: 15,
    marginLeft: 15,
  },
});
