import React, { useState } from "react";

import { StatusBar, StyleSheet, View, Image } from "react-native";
import { TextInput } from "react-native-paper";
import { Button } from "react-native-paper";
import Loader from "../components/Loader";
import AsyncStorage from "@react-native-async-storage/async-storage";
import CookieManager from "@react-native-cookies/cookies";

export default function Login({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [website, setWebsite] = useState("");
  const [passwordVisible, setPasswordVisible] = useState(true);
  const [loading, setLoading] = useState(false);
  const handleLogin = async () => {
    try {
      // Show loader
      setLoading(true);
      await fetch("https://smtksa.com/web/session/authenticate", {
        method: "POST",
        credentials: "same-origin",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          jsonrpc: "2.0",
          params: {
            db: website,
            login: email,
            password: password,
          },
        }),
      }).then(async (response) => {
        const data = await response.json();
        if (data.error) {
          const error = data.error;
          const errorMessage = error.data;
          return Promise.reject(errorMessage.message);
        } else {
          storeSalesPersonData(data.result);
          const session = response.headers.get("set-cookie");
          console.log(session);
          CookieManager.setFromResponse("https://smtksa.com/web", session).then(
            (success) => {
              console.log("CookieManager.setFromResponse =>", success);
            }
          );
          navigation.navigate("BeginScreen");
        }
      });
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const storeSalesPersonData = async (salesperson) => {
    try {
      //console.log("Hello", cust);
      const jsonValue = JSON.stringify(salesperson);
      await AsyncStorage.setItem("salesPerson", jsonValue);
    } catch (e) {
      console.log("Error", e);
    }
  };
  return (
    <View style={styles.container}>
      <Loader loading={loading} />
      <Image
        source={require("../assets/logo.png")}
        style={{
          width: 240,
          height: 160,
          borderRadius: 60,
          alignSelf: "center",
          marginRight: 20 / 2,
        }}
      />
      <StatusBar backgroundColor="#3c8" hidden={false} />
      <TextInput
        style={styles.input}
        label="Database"
        left={<TextInput.Icon name="database" color={"#3c8"} />}
        keyboardType="email-address"
        //selectionColor="red"
        activeUnderlineColor="green"
        underlineColor="green"
        mode="outlined"
        theme={{ colors: { primary: "#3c8" } }}
        onChangeText={(e) => setWebsite(e)}
      />
      <TextInput
        style={styles.input}
        label="Email"
        left={<TextInput.Icon name="email" color={"#3c8"} />}
        keyboardType="email-address"
        //selectionColor="red"
        activeUnderlineColor="green"
        underlineColor="green"
        mode="outlined"
        theme={{ colors: { primary: "#3c8" } }}
        onChangeText={(e) => setEmail(e)}
      />
      <TextInput
        style={styles.input}
        label="Password"
        left={<TextInput.Icon name="lock" color={"#3c8"} />}
        secureTextEntry={passwordVisible}
        right={
          <TextInput.Icon
            name={passwordVisible ? "eye" : "eye-off"}
            onPress={() => setPasswordVisible(!passwordVisible)}
          />
        }
        keyboardType="password"
        underlineColor="red"
        theme={{ colors: { primary: "#3c8" } }}
        mode="outlined"
        onChangeText={(e) => setPassword(e)}
      />
      <View style={{ marginTop: 25 }}>
        <Button
          mode="contained"
          color="#3c8"
          disabled={!(email && password && website)}
          labelStyle={{ color: "white" }}
          onPress={() => handleLogin()}
        >
          Login
        </Button>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "#ecf0f1",
    marginLeft: 15,
    marginRight: 15,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
  },
  input: {
    borderColor: "#3c8",
  },
});
